import React, {
    createContext,
    useContext,
    useEffect,
    useState,
    ReactNode,
} from 'react';
import type { User, UserRole } from '../types';
import {
    login,
    logout,
    register,
    subscribeToAuth,
} from '../api/authApi';

// Definerer kontekstens verdi og funksjoner for autentisering
interface AuthContextValue {
    user: User | null;
    loading: boolean;
    loginWithEmail: (email: string, password: string) => Promise<void>;
    registerWithEmail: (
        email: string,
        password: string,
        name: string,
        role?: UserRole
    ) => Promise<void>;
    signOut: () => Promise<void>;
}

// Oppretter autentiseringskonteksten
const AuthContext = createContext<AuthContextValue | undefined>(undefined);

// Provider-komponenten som håndterer autentiseringstilstand og funksjoner
interface Props {
    children: ReactNode;
}

// Leverer autentiseringskonteksten til underkomponenter
export const AuthProvider: React.FC<Props> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);

    // Abonnerer på autentiseringstilstand ved mount
    useEffect(() => {
        const unsubscribe = subscribeToAuth((u) => {
            setUser(u);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    // Funksjoner for pålogging, registrering og utlogging
    const loginWithEmail = async (email: string, password: string) => {
        setLoading(true);
        try {
            const loggedIn = await login(email, password);
            setUser(loggedIn);
        } finally {
            setLoading(false);
        }
    };

    // Registrerer ny bruker med e-post, passord, navn og rolle
    const registerWithEmail = async (
        email: string,
        password: string,
        name: string,
        role: UserRole = 'volunteer'
    ) => {
        setLoading(true);
        try {
            const registered = await register(email, password, name, role);
            setUser(registered);
        } finally {
            setLoading(false);
        }
    };

    // Logger ut gjeldende bruker
    const signOut = async () => {
        setLoading(true);
        try {
            await logout();
            setUser(null);
        } finally {
            setLoading(false);
        }
    };

    // Returnerer provider med kontekstverdi
    return (
        <AuthContext.Provider
            value={{ user, loading, loginWithEmail, registerWithEmail, signOut }}
        >
            {children}
        </AuthContext.Provider>
    );
};

// Hook for å bruke autentiseringskonteksten i komponenter
export const useAuth = () => {
    const ctx = useContext(AuthContext);
    if (!ctx) throw new Error('useAuth må brukes inne i AuthProvider');
    return ctx;
};
