// components/DugnadCard.tsx
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { Dugnad } from '../types';
import Colors from '../constants/Colors';
import { formatDugnadDateTime, getComputedStatus } from '../utils/dugnadUtils';

interface Props {
  dugnad: Dugnad;
  onPress: () => void;
  isFavorite?: boolean;
  onToggleFavorite?: () => void;
}

export const DugnadCard: React.FC<Props> = ({
  dugnad,
  onPress,
  isFavorite,
  onToggleFavorite,
}) => {
  const status = getComputedStatus(dugnad);

  const hasImage =
    Array.isArray((dugnad as any).images) &&
    (dugnad as any).images.length > 0;
  const imageUrl = hasImage ? (dugnad as any).images[0] : undefined;

  const remaining =
    dugnad.volunteersNeeded - dugnad.volunteersRegistered > 0
      ? dugnad.volunteersNeeded - dugnad.volunteersRegistered
      : 0;

  const isFull =
    dugnad.volunteersRegistered >= dugnad.volunteersNeeded &&
    status !== 'completed';

  const statusLabel =
    status === 'completed'
      ? 'Fullført'
      : status === 'ongoing'
        ? 'Pågår'
        : isFull
          ? 'Fullt'
          : 'Ledig';

  const computedFavorite =
    typeof isFavorite === 'boolean'
      ? isFavorite
      : (dugnad as any).isFavorite ?? false;

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={onPress}
      activeOpacity={0.9}
    >
      {/* BILDE */}
      <View style={styles.imageWrapper}>
        {imageUrl ? (
          <Image source={{ uri: imageUrl }} style={styles.image} />
        ) : (
          <View style={styles.imagePlaceholder}>
            <Ionicons name="image-outline" size={24} color="#ffffff" />
          </View>
        )}

        {/* STATUS + FAVORITT SIDE VED SIDE */}
        <View style={styles.topRightRow}>
          <View style={[styles.statusPill, isFull && styles.statusPillFull]}>
            <Text style={styles.statusText}>{statusLabel}</Text>
          </View>

          <TouchableOpacity
            style={styles.favoriteButton}
            onPress={onToggleFavorite}
            activeOpacity={onToggleFavorite ? 0.7 : 1}
          >
            <Ionicons
              name={computedFavorite ? 'heart' : 'heart-outline'}
              size={20}
              color={computedFavorite ? '#e11d48' : '#111827'}
            />
          </TouchableOpacity>
        </View>
      </View>

      {/* INNHOLD */}
      <View style={styles.content}>
        <Text style={styles.title} numberOfLines={2}>
          {dugnad.title}
        </Text>

        <View style={styles.categoryPill}>
          <Text style={styles.categoryPillText}>{dugnad.category}</Text>
        </View>

        <Text style={styles.description} numberOfLines={2}>
          {dugnad.description}
        </Text>

        {/* INFO-RADER */}
        <View style={styles.infoRow}>
          <Ionicons
            name="calendar-outline"
            size={14}
            color={Colors.text}
            style={styles.infoIcon}
          />
          <Text style={styles.infoText}>
            {formatDugnadDateTime(dugnad)}
          </Text>
        </View>

        <View style={styles.infoRow}>
          <Ionicons
            name="location-outline"
            size={14}
            color={Colors.text}
            style={styles.infoIcon}
          />
          <Text style={styles.infoText}>
            {dugnad.location || dugnad.address}
          </Text>
        </View>

        <View style={styles.infoRow}>
          <Ionicons
            name="people-outline"
            size={14}
            color={Colors.text}
            style={styles.infoIcon}
          />
          <Text style={styles.infoText}>
            {dugnad.volunteersRegistered}/{dugnad.volunteersNeeded} frivillige{' '}
            {remaining > 0 && (
              <Text style={styles.infoRemaining}>
                ({remaining} ledig)
              </Text>
            )}
          </Text>
        </View>

        {/* SE DETALJER */}
        <TouchableOpacity
          onPress={onPress}
          activeOpacity={0.85}
          style={styles.detailsButton}
        >
          <Text style={styles.detailsButtonText}>Se detaljer</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  imageWrapper: {
    width: '100%',
    height: 190,
    backgroundColor: '#E5E7EB',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  imagePlaceholder: {
    flex: 1,
    backgroundColor: '#9CA3AF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  topRightRow: {
    position: 'absolute',
    top: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusPill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: '#000000',
    marginRight: 8,
  },
  statusPillFull: {
    backgroundColor: '#b91c1c',
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },
  favoriteButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 16,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  categoryPill: {
    alignSelf: 'flex-start',
    borderRadius: 999,
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginBottom: 8,
  },
  categoryPillText: {
    fontSize: 11,
    fontWeight: '500',
  },
  description: {
    fontSize: 13,
    color: Colors.text,
    marginBottom: 12,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  infoIcon: {
    marginRight: 6,
  },
  infoText: {
    fontSize: 13,
    color: Colors.text,
  },
  infoRemaining: {
    fontSize: 13,
    color: '#059669',
    fontWeight: '500',
  },
  detailsButton: {
    marginTop: 16,
    backgroundColor: '#020617',
    paddingVertical: 12,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
  },
  detailsButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
});
