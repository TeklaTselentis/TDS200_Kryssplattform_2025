// components/CreateDugnadForm.tsx
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import Colors from '../constants/Colors';
import { Button } from './ui/Button';
import type { Dugnad } from '../types';
import {
  createDugnad,
  updateDugnad,
  type CreateDugnadInput,
} from '../api/firebase';
import { useAuth } from '../providers/authctx';

interface Props {
  initialDugnad?: Dugnad | null;
  onSaved?: (dugnad: Dugnad) => void;
  onCancel?: () => void;
}

const CATEGORIES = [
  'Park og natur',
  'Miljø',
  'Vedlikehold',
  'Sosialt',
  'Barn og familie',
  'Sport og aktivitet',
  'Kultur',
  'Annet',
];

function parseDateFromInput(raw: string): Date | null {
  const v = raw.trim();
  if (!v) return null;

  let d: number;
  let m: number;
  let y: number;

  if (v.includes('-')) {
    const [yStr, mStr, dStr] = v.split('-');
    y = Number(yStr);
    m = Number(mStr);
    d = Number(dStr);
  } else {
    const sep = v.includes('.') ? '.' : '/';
    const [dStr, mStr, yStr] = v.split(sep);
    d = Number(dStr);
    m = Number(mStr);
    y = Number(yStr);
  }

  if (!d || !m || !y) return null;
  const date = new Date(y, m - 1, d);
  if (Number.isNaN(date.getTime())) return null;
  return date;
}

export const CreateDugnadForm: React.FC<Props> = ({
  initialDugnad,
  onSaved,
  onCancel,
}) => {
  const { user } = useAuth();
  const isEdit = !!initialDugnad;

  const [title, setTitle] = useState(initialDugnad?.title ?? '');
  const [description, setDescription] = useState(
    initialDugnad?.description ?? ''
  );

  const [category, setCategory] = useState<string | null>(
    initialDugnad?.category ?? null
  );
  const [categoryOpen, setCategoryOpen] = useState(false);

  const [location, setLocation] = useState(initialDugnad?.location ?? '');
  const [address, setAddress] = useState(initialDugnad?.address ?? '');

  const [dateInput, setDateInput] = useState(
    initialDugnad
      ? `${String(initialDugnad.date.getDate()).padStart(2, '0')}.${String(
        initialDugnad.date.getMonth() + 1
      ).padStart(2, '0')}.${initialDugnad.date.getFullYear()}`
      : ''
  );

  const [startTime, setStartTime] = useState(initialDugnad?.startTime ?? '');
  const [endTime, setEndTime] = useState(initialDugnad?.endTime ?? '');

  const [volunteersNeeded, setVolunteersNeeded] = useState(
    initialDugnad?.volunteersNeeded?.toString() ?? '10'
  );

  const [tasks, setTasks] = useState<string[]>(
    initialDugnad?.tasks ?? []
  );
  const [taskInput, setTaskInput] = useState('');

  const [imageUrl, setImageUrl] = useState(
    initialDugnad?.images?.[0] ?? ''
  );

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!user) {
    return (
      <View style={styles.section}>
        <Text>Du må være logget inn som arrangør.</Text>
      </View>
    );
  }

  const hasRequiredFields =
    title.trim().length > 0 &&
    description.trim().length > 0 &&
    category &&
    location.trim().length > 0 &&
    address.trim().length > 0 &&
    dateInput.trim().length > 0 &&
    startTime.trim().length > 0 &&
    endTime.trim().length > 0 &&
    volunteersNeeded.trim().length > 0;

  const handleAddTask = () => {
    const trimmed = taskInput.trim();
    if (!trimmed) return;
    setTasks((prev) => [...prev, trimmed]);
    setTaskInput('');
  };

  const handleRemoveTask = (index: number) => {
    setTasks((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    setError(null);

    if (!hasRequiredFields) {
      setError('Fyll ut alle obligatoriske felter markert med *.');
      return;
    }

    const parsedDate = parseDateFromInput(dateInput);
    if (!parsedDate) {
      setError('Ugyldig dato. Bruk f.eks. 20.11.2025 eller 2025-11-20.');
      return;
    }

    const volunteers = parseInt(volunteersNeeded, 10);
    if (Number.isNaN(volunteers) || volunteers <= 0) {
      setError('Antall frivillige må være et positivt tall.');
      return;
    }

    const input: CreateDugnadInput = {
      title: title.trim(),
      description: description.trim(),
      category: category ?? 'Annet',
      location: location.trim(),
      address: address.trim(),
      date: parsedDate,
      startTime: startTime.trim(),
      endTime: endTime.trim(),
      tasks,
      volunteersNeeded: volunteers,
      organizerId: user.id,
      organizerName: user.name,
      organizerEmail: user.email,
      images: imageUrl.trim()
        ? [imageUrl.trim()]
        : initialDugnad?.images ?? [],
      latitude: initialDugnad?.latitude ?? null,
      longitude: initialDugnad?.longitude ?? null,
    };

    setLoading(true);
    try {
      if (isEdit && initialDugnad) {
        await updateDugnad(initialDugnad.id, input);
        onSaved?.({
          ...initialDugnad,
          ...input,
        });
      } else {

        const created = await createDugnad(input);
        onSaved?.(created);

        setTitle('');
        setDescription('');
        setCategory(null);
        setCategoryOpen(false);
        setLocation('');
        setAddress('');
        setDateInput('');
        setStartTime('');
        setEndTime('');
        setVolunteersNeeded('10');
        setTasks([]);
        setTaskInput('');
        setImageUrl('');

      }
    } catch (e) {
      console.error('Feil ved lagring av dugnad', e);
      setError('Kunne ikke lagre dugnaden. Sjekk nettverk og Firestore-regler.');
    } finally {
      setLoading(false);
    }
  };


  return (
    <View>
      {/* Tittel */}
      <View style={styles.section}>
        <Text style={styles.label}>Tittel *</Text>
        <TextInput
          style={styles.input}
          placeholder="F.eks. Vårrens i Frognerparken"
          placeholderTextColor={Colors.textMuted}
          value={title}
          onChangeText={setTitle}
        />
      </View>

      {/* Beskrivelse */}
      <View style={styles.section}>
        <Text style={styles.label}>Beskrivelse *</Text>
        <TextInput
          style={[styles.input, styles.inputMultiline]}
          placeholder="Beskriv dugnaden i detalj..."
          placeholderTextColor={Colors.textMuted}
          value={description}
          onChangeText={setDescription}
          multiline
          textAlignVertical="top"
        />
      </View>

      {/* Kategori */}
      <View style={styles.section}>
        <Text style={styles.label}>Kategori *</Text>
        <TouchableOpacity
          style={styles.select}
          onPress={() => setCategoryOpen((prev) => !prev)}
          activeOpacity={0.8}
        >
          <Text
            style={[
              styles.selectText,
              !category && { color: Colors.textMuted },
            ]}
          >
            {category ?? 'Velg kategori'}
          </Text>
          <Ionicons
            name={categoryOpen ? 'chevron-up' : 'chevron-down'}
            size={18}
            color="#6B7280"
          />
        </TouchableOpacity>

        {categoryOpen && (
          <View style={styles.selectDropdown}>
            {CATEGORIES.map((cat) => (
              <TouchableOpacity
                key={cat}
                style={styles.selectOption}
                onPress={() => {
                  setCategory(cat);
                  setCategoryOpen(false);
                }}
              >
                <Text style={styles.selectOptionText}>{cat}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>

      {/* Antall frivillige */}
      <View style={styles.section}>
        <Text style={styles.label}>Antall frivillige trengs *</Text>
        <TextInput
          style={styles.input}
          keyboardType="number-pad"
          value={volunteersNeeded}
          onChangeText={setVolunteersNeeded}
        />
      </View>

      {/* Sted */}
      <View style={styles.section}>
        <Text style={styles.label}>Sted *</Text>
        <TextInput
          style={styles.input}
          placeholder="F.eks. Frognerparken"
          placeholderTextColor={Colors.textMuted}
          value={location}
          onChangeText={setLocation}
        />
      </View>

      {/* Adresse */}
      <View style={styles.section}>
        <Text style={styles.label}>Adresse *</Text>
        <TextInput
          style={styles.input}
          placeholder="F.eks. Kirkeveien, 0268 Oslo"
          placeholderTextColor={Colors.textMuted}
          value={address}
          onChangeText={setAddress}
        />
      </View>

      {/* Dato */}
      <View style={styles.section}>
        <Text style={styles.label}>Dato *</Text>
        <View style={styles.inputWrapper}>
          <TextInput
            style={styles.input}
            placeholder="dd/mm/yyyy"
            placeholderTextColor={Colors.textMuted}
            value={dateInput}
            onChangeText={setDateInput}
            keyboardType="numbers-and-punctuation"
          />
          <Ionicons
            name="calendar-outline"
            size={18}
            color="#9CA3AF"
            style={styles.inputIconRight}
          />
        </View>
      </View>

      {/* Tid fra / til */}
      <View style={[styles.section, styles.row]}>
        <View style={{ flex: 1, marginRight: 8 }}>
          <Text style={styles.label}>Fra *</Text>
          <View style={styles.inputWrapper}>
            <TextInput
              style={styles.input}
              placeholder="--:--"
              placeholderTextColor={Colors.textMuted}
              value={startTime}
              onChangeText={setStartTime}
              keyboardType="numbers-and-punctuation"
            />
            <Ionicons
              name="time-outline"
              size={18}
              color="#9CA3AF"
              style={styles.inputIconRight}
            />
          </View>
        </View>

        <View style={{ flex: 1, marginLeft: 8 }}>
          <Text style={styles.label}>Til *</Text>
          <View style={styles.inputWrapper}>
            <TextInput
              style={styles.input}
              placeholder="--:--"
              placeholderTextColor={Colors.textMuted}
              value={endTime}
              onChangeText={setEndTime}
              keyboardType="numbers-and-punctuation"
            />
            <Ionicons
              name="time-outline"
              size={18}
              color="#9CA3AF"
              style={styles.inputIconRight}
            />
          </View>
        </View>
      </View>

      {/* Bilde-URL */}
      <View style={styles.section}>
        <Text style={styles.label}>Bilde-URL (valgfritt)</Text>
        <TextInput
          style={styles.input}
          placeholder="https://..."
          placeholderTextColor={Colors.textMuted}
          value={imageUrl}
          onChangeText={setImageUrl}
          autoCapitalize="none"
        />
        <Text style={styles.helperText}>
          URL til bilde, eller la feltet være tomt for standardbilde
        </Text>
      </View>

      {/* Oppgaver */}
      <View style={styles.section}>
        <View style={styles.tasksHeaderRow}>
          <Text style={styles.label}>Oppgaver</Text>
          <TouchableOpacity onPress={handleAddTask}>
            <Text style={styles.addTaskText}>+ Legg til</Text>
          </TouchableOpacity>
        </View>
        <TextInput
          style={styles.input}
          placeholder="F.eks. Rake løv"
          placeholderTextColor={Colors.textMuted}
          value={taskInput}
          onChangeText={setTaskInput}
          onSubmitEditing={handleAddTask}
        />

        {tasks.map((task, index) => (
          <View key={`${task}-${index}`} style={styles.taskPillRow}>
            <Text style={styles.taskPillText}>{task}</Text>
            <TouchableOpacity onPress={() => handleRemoveTask(index)}>
              <Ionicons name="close" size={16} color="#6B7280" />
            </TouchableOpacity>
          </View>
        ))}
      </View>

      {/* Error + knapper */}
      {error && (
        <Text style={styles.errorText}>{error}</Text>
      )}

      <View style={styles.buttonRow}>
        <Button
          title={isEdit ? 'Lagre endringer' : 'Opprett'}
          onPress={handleSubmit}
          loading={loading}
          disabled={loading}
        />
        {onCancel && (
          <Button
            title="Avbryt"
            variant="outline"
            onPress={onCancel}
            style={{ marginTop: 8 }}
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  section: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  label: {
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 6,
  },
  inputWrapper: {
    position: 'relative',
  },
  input: {
    borderRadius: 10,
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: Colors.text,
  },
  inputMultiline: {
    minHeight: 90,
  },
  inputIconRight: {
    position: 'absolute',
    right: 10,
    top: '50%',
    marginTop: -9,
  },
  row: {
    flexDirection: 'row',
  },
  select: {
    borderRadius: 10,
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 12,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  selectText: {
    fontSize: 14,
    color: Colors.text,
  },
  selectDropdown: {
    marginTop: 4,
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    overflow: 'hidden',
  },
  selectOption: {
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  selectOptionText: {
    fontSize: 14,
    color: Colors.text,
  },
  helperText: {
    marginTop: 4,
    fontSize: 11,
    color: Colors.textMuted,
  },
  tasksHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  addTaskText: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '500',
  },
  taskPillRow: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    marginTop: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: '#E5E7EB',
  },
  taskPillText: {
    fontSize: 13,
    marginRight: 6,
  },
  buttonRow: {
    paddingHorizontal: 16,
    paddingTop: 24,
    paddingBottom: 32,
  },
  errorText: {
    marginTop: 8,
    paddingHorizontal: 16,
    fontSize: 12,
    color: 'red',
  },
});
