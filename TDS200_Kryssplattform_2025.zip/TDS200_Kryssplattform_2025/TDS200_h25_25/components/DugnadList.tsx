// components/DugnadList.tsx
import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import type { Dugnad } from '../types';
import { DugnadCard } from './DugnadCard';
import Colors from '../constants/Colors';

type Props = {
  dugnads?: Dugnad[];
  onSelect: (dugnad: Dugnad) => void;
  favorites?: string[];
  onToggleFavorite?: (dugnad: Dugnad) => void;
  selectedCategory?: string | null;
};

export const DugnadList: React.FC<Props> = ({
  dugnads,
  onSelect,
  favorites,
  onToggleFavorite,
  selectedCategory,
}) => {
  const safeDugnads: Dugnad[] = Array.isArray(dugnads) ? dugnads : [];

  if (safeDugnads.length === 0) {
    const msg = selectedCategory
      ? `Det er ikke opprettet noen dugnader i kategorien «${selectedCategory}» ennå.`
      : 'Ingen dugnader å vise.';

    return (
      <View style={styles.emptyWrapper}>
        <Text style={styles.emptyText}>{msg}</Text>
      </View>
    );
  }

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.listContent}
    >
      {safeDugnads.map((item) => (
        <View key={item.id} style={styles.itemWrapper}>
          <DugnadCard
            dugnad={item}
            onPress={() => onSelect(item)}
            isFavorite={favorites?.includes(item.id)}
            onToggleFavorite={
              onToggleFavorite ? () => onToggleFavorite(item) : undefined
            }
          />
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  listContent: {
    paddingBottom: 16,
  },
  itemWrapper: {
    marginBottom: 10,
  },
  emptyWrapper: {
    paddingVertical: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: Colors.textMuted,
    textAlign: 'center',
  },
});

export default DugnadList;
