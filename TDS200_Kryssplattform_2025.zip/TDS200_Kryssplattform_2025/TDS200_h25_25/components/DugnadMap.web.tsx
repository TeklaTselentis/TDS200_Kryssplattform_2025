// components/DugnadMap.web.tsx
import React, { useEffect, useRef } from "react";
import * as L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Dugnad } from "../types";
import { getComputedStatus } from "../utils/dugnadUtils";

type Props = {
dugnads: Dugnad[];
};

const OSLO_CENTER: [number, number] = [59.9139, 10.7522];

const mapStyle: React.CSSProperties = {
width: "100%",
height: 700,
borderRadius: 16,
overflow: "hidden",
};

const DugnadMapWeb: React.FC<Props> = ({ dugnads }) => {
const containerRef = useRef<HTMLDivElement | null>(null);
const mapRef = useRef<L.Map | null>(null);
const markersLayerRef = useRef<L.LayerGroup | null>(null);

useEffect(() => {
if (!containerRef.current || mapRef.current) return;

const map = L.map(containerRef.current, {
center: OSLO_CENTER,
zoom: 11,
zoomControl: true,
});

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
maxZoom: 19,
attribution: '&copy; OpenStreetMap contributors',
}).addTo(map);

const layer = L.layerGroup().addTo(map);
mapRef.current = map;
markersLayerRef.current = layer;


setTimeout(() => {
map.invalidateSize();
}, 0);

const handleResize = () => map.invalidateSize();
window.addEventListener("resize", handleResize);

return () => {
window.removeEventListener("resize", handleResize);
map.remove();
mapRef.current = null;
markersLayerRef.current = null;
};
}, []);

useEffect(() => {
const map = mapRef.current;
const layer = markersLayerRef.current;
if (!map || !layer) return;

layer.clearLayers();

dugnads.forEach((d, index) => {
let lat =
typeof d.latitude === "number" ? d.latitude : null;
let lng =
typeof d.longitude === "number" ? d.longitude : null;

if (lat == null || lng == null) {
const radius = 0.08;
const angle = index * 0.7;
lat = OSLO_CENTER[0] + Math.sin(angle) * radius;
lng = OSLO_CENTER[1] + Math.cos(angle) * radius;
}

const status = getComputedStatus(d);
let color = "#2563EB"; 
if (status === "ongoing") color = "#16A34A";
if (status === "completed") color = "#4B5563";

const icon = L.divIcon({
className: "",
html: `<div style="
width:14px;
height:14px;
border-radius:999px;
background:${color};
border:2px solid white;
box-shadow:0 0 6px rgba(0,0,0,0.35);
"></div>`,
iconSize: [14, 14],
iconAnchor: [7, 7],
});

const marker = L.marker([lat, lng], { icon });
marker.bindPopup(`<b>${d.title}</b><br/>${d.address ?? ""}`);
marker.addTo(layer);
});
}, [dugnads]);

return <div ref={containerRef} style={mapStyle} />;
};

export default DugnadMapWeb;

