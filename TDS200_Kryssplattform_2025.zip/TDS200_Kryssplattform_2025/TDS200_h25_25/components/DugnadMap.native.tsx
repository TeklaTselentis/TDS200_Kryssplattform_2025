// components/DugnadMap.native.tsx
import React, { useMemo, useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import MapView, { Marker, Region } from "react-native-maps";
import type { Dugnad } from "../types";
import { getComputedStatus } from "../utils/dugnadUtils";

type Props = {
    dugnads: Dugnad[];
};

const OSLO_CENTER = {
    latitude: 59.9139,
    longitude: 10.7522,
};

const INITIAL_DELTA = 0.25;

export default function DugnadMapNative({ dugnads }: Props) {
    const [region, setRegion] = useState<Region>({
        ...OSLO_CENTER,
        latitudeDelta: INITIAL_DELTA,
        longitudeDelta: INITIAL_DELTA,
    });

    const markers = useMemo(
        () =>
            dugnads.map((d, index) => {
                let lat =
                    typeof d.latitude === "number" ? d.latitude : null;
                let lng =
                    typeof d.longitude === "number" ? d.longitude : null;

                if (lat == null || lng == null) {
                    const radius = 0.08;
                    const angle = index * 0.7;
                    lat = OSLO_CENTER.latitude + Math.sin(angle) * radius;
                    lng = OSLO_CENTER.longitude + Math.cos(angle) * radius;
                }

                const status = getComputedStatus(d);
                let color = "#2563EB";
                if (status === "ongoing") color = "#16A34A";
                if (status === "completed") color = "#4B5563";

                return {
                    id: d.id,
                    title: d.title,
                    coordinate: { latitude: lat, longitude: lng },
                    color,
                };
            }),
        [dugnads]
    );

    const handleZoom = (factor: number) => {
        setRegion((prev) => {
            const nextDelta = Math.max(
                0.02,
                Math.min(prev.latitudeDelta * factor, 1.5)
            );
            return {
                ...prev,
                latitudeDelta: nextDelta,
                longitudeDelta: nextDelta,
            };
        });
    };

    return (
        <View style={styles.container}>
            <View style={styles.mapWrapper}>
                <MapView
                    style={styles.map}
                    region={region}
                    onRegionChangeComplete={setRegion}
                >
                    {markers.map((m) => (
                        <Marker
                            key={m.id}
                            coordinate={m.coordinate}
                            pinColor={m.color}
                            title={m.title}
                        />
                    ))}
                </MapView>

                {/* Zoom-knapper */}
                <View style={styles.zoomControls}>
                    <TouchableOpacity
                        style={styles.zoomButton}
                        onPress={() => handleZoom(0.7)}
                    >
                        <Text style={styles.zoomText}>+</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.zoomButton}
                        onPress={() => handleZoom(1.3)}
                    >
                        <Text style={styles.zoomText}>−</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        marginTop: 12,
    },
    mapWrapper: {
        marginTop: 8,
        width: "100%",
        height: 570,
        borderRadius: 16,
        overflow: "hidden",
    },
    map: {
        flex: 1,
    },
    zoomControls: {
        position: "absolute",
        right: 12,
        bottom: 12,
        alignItems: "center",
    },
    zoomButton: {
        width: 32,
        height: 32,
        borderRadius: 16,
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        shadowColor: "#000",
        shadowOpacity: 0.15,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
        marginBottom: 6,
        elevation: 3,
    },
    zoomText: {
        fontSize: 18,
        fontWeight: "600",
    },
});

