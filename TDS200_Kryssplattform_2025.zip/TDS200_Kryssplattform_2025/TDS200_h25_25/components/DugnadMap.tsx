// components/ui/DugnadMap.web.tsx
import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import * as L from 'leaflet';
import type { Dugnad } from '../types';
import { getComputedStatus } from '../utils/dugnadUtils';

type Props = {
    dugnads: Dugnad[];
};

const DugnadMapWeb: React.FC<Props> = ({ dugnads }) => {
    const mapRef = useRef<L.Map | null>(null);

    useEffect(() => {
        if (!mapRef.current) {
            const map = L.map('dugnad-map', {
                center: [59.9139, 10.7522],
                zoom: 11,
            });

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; OpenStreetMap contributors',
            }).addTo(map);

            mapRef.current = map;
        }

        if (!mapRef.current) return;

        mapRef.current.eachLayer((layer: any) => {
            if (layer instanceof L.Marker) {
                mapRef.current!.removeLayer(layer);
            }
        });

        dugnads.forEach((d) => {
            const lat = d.latitude;
            const lng = d.longitude;
            if (lat == null || lng == null) return;

            const status = getComputedStatus(d);
            const color =
                status === 'completed'
                    ? 'gray'
                    : status === 'ongoing'
                        ? 'green'
                        : 'blue';

            const icon = L.divIcon({
                className: '',
                html: `<div style="
width: 12px;
height: 12px;
border-radius: 999px;
background-color: ${color};
border: 2px solid white;
box-shadow: 0 0 4px rgba(0,0,0,0.4);
"></div>`,
            });

            L.marker([lat, lng], { icon }).addTo(mapRef.current!);
        });
    }, [dugnads]);

    return (
        <View style={{ flex: 1 }}>
            <div
                id="dugnad-map"
                style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: 15,
                    overflow: 'hidden',
                }}
            />
        </View>
    );
};

export default DugnadMapWeb;
