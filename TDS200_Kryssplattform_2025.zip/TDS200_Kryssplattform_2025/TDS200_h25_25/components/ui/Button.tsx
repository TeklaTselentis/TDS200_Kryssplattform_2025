// components/ui/Button.tsx
import React from 'react';
import {
  ActivityIndicator,
  GestureResponderEvent,
  StyleProp,
  StyleSheet,
  Text,
  TouchableOpacity,
  ViewStyle,
} from 'react-native';
import Colors from '../../constants/Colors';

type Variant = 'default' | 'outline' | 'secondary' | 'danger' | 'success';
type Size = 'sm' | 'md';

interface Props {
  title: string;
  onPress: (event: GestureResponderEvent) => void;
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
}

export const Button: React.FC<Props> = ({
  title,
  onPress,
  variant = 'default',
  size = 'md',
  loading = false,
  disabled = false,
  style,
}) => {
  const isDisabled = disabled || loading;

  const containerStyles = [
    styles.base,
    variantStyles[variant],
    sizeStyles[size],
    isDisabled && styles.disabled,
    style,
  ];

  const textStyles = [
    styles.textBase,
    textVariantStyles[variant],
    size === 'sm' && styles.textSmall,
  ];

  return (
    <TouchableOpacity
      style={containerStyles}
      onPress={onPress}
      disabled={isDisabled}
      activeOpacity={0.8}
    >
      {loading && (
        <ActivityIndicator size="small" style={{ marginRight: 6 }} />
      )}
      <Text style={textStyles} numberOfLines={1}>
        {title}
      </Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 999,
    borderWidth: 1,
  },
  textBase: {
    fontWeight: '600',
  },
  textSmall: {
    fontSize: 12,
  },
  disabled: {
    opacity: 0.6,
  },
});

const variantStyles: Record<Variant, ViewStyle> = {
  default: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  outline: {
    backgroundColor: 'transparent',
    borderColor: Colors.border,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  secondary: {
    backgroundColor: '#e5e7eb',
    borderColor: '#e5e7eb',
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  danger: {
    backgroundColor: '#ef4444',
    borderColor: '#ef4444',
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  success: {
    backgroundColor: '#16a34a',
    borderColor: '#16a34a',
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
};

const textVariantStyles: Record<Variant, any> = {
  default: {
    color: '#fff',
    fontSize: 14,
  },
  outline: {
    color: Colors.text,
    fontSize: 13,
  },
  secondary: {
    color: Colors.text,
    fontSize: 13,
  },
  danger: {
    color: '#fff',
    fontSize: 13,
  },
  success: {
    color: '#fff',
    fontSize: 13,
  },
};

const sizeStyles: Record<Size, ViewStyle> = {
  md: {
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  sm: {
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
};

export default Button;
