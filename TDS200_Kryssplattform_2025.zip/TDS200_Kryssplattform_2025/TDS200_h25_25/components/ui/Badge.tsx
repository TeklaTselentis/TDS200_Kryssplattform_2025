// components/ui/Badge.tsx
import React from 'react';
import { View, Text, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import Colors from '../../constants/Colors';

type Variant = 'default' | 'secondary' | 'success' | 'danger';

interface Props {
    label: string;
    variant?: Variant;
    style?: StyleProp<ViewStyle>;
}

export const Badge: React.FC<Props> = ({ label, variant = 'default', style }) => {
    const bg = {
        default: '#e5e7eb',
        secondary: '#f3f4f6',
        success: '#dcfce7',
        danger: '#fee2e2',
    }[variant];

    const color = {
        default: '#374151',
        secondary: '#4b5563',
        success: '#15803d',
        danger: '#b91c1c',
    }[variant];

    return (
        <View style={[styles.badge, { backgroundColor: bg }, style]}>
            <Text style={[styles.text, { color }]}>{label}</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    badge: {
        borderRadius: 999,
        paddingHorizontal: 8,
        paddingVertical: 2,
    },
    text: {
        fontSize: 11,
        fontWeight: '500',
    },
});

export default Badge;
