import { useEffect, useState, useCallback } from 'react';
import type { UserStats } from '../types';
import { getRegistrationsForUser, getFavoritesForUser, getDugnads } from '../api/firebase';
import { getComputedStatus } from '../utils/dugnadUtils';

// Returntype for hooken: liste, lastestatus, feil og refresh-funksjon
interface UseUserStatsResult {
    stats: UserStats | null;
    loading: boolean;
    error: string | null;
    refresh: () => Promise<void>;
}

// Hook for å hente brukerstatistikk som deltakelser og favoritter
export const useUserStats = (userId?: string): UseUserStatsResult => {
    const [stats, setStats] = useState<UserStats | null>(null);
    const [loading, setLoading] = useState(!!userId);
    const [error, setError] = useState<string | null>(null);

    // Laster brukerstatistikk fra Firestore
    const load = useCallback(async () => {
        if (!userId) {
            setStats(null);
            setLoading(false);
            return;
        }
        setLoading(true);
        setError(null);
        try {
            const [registrations, favorites, dugnads] = await Promise.all([
                getRegistrationsForUser(userId),
                getFavoritesForUser(userId),
                getDugnads(),
            ]);

            // Filtrer registreringer for aktive deltakelser
            const activeRegs = registrations.filter((r) => r.status === 'registered');

            // Beregn statistikkverdier
            let upcoming = 0;
            let completed = 0;
            let ongoing = 0;

            // Telle opp deltakelser basert på dugnadsstatus
            for (const reg of activeRegs) {
                const d = dugnads.find((x) => x.id === reg.dugnadId);
                if (!d) continue;
                const s = getComputedStatus(d);
                if (s === 'upcoming') upcoming++;
                else if (s === 'completed') completed++;
                else if (s === 'ongoing') ongoing++;
            }

            // Oppdater state med ny statistikk
            setStats({
                totalParticipations: activeRegs.length,
                upcomingDugnads: upcoming,
                completedDugnads: completed,
                ongoingDugnads: ongoing,
                favorites: favorites.length,
            });
        } catch (e) {
            console.error('Feil ved henting av brukerstatistikk', e);
            setError('Kunne ikke hente statistikk.');
        } finally {
            setLoading(false);
        }
    }, [userId]);

    // Last inn statistikk ved mount eller når userId endres
    useEffect(() => {
        load();
    }, [load]);
    
    // Returner statistikk, lastestatus, feil og refresh-funksjon
    return { stats, loading, error, refresh: load };
};

