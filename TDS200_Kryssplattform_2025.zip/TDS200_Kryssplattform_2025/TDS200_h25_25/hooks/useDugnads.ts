import { useEffect, useMemo, useState, useCallback } from 'react';
import type { Dugnad } from '../types';
import { getDugnads } from '../api/firebase';
import {
    filterDugnadsBySearch,
    sortDugnadsForList,
} from '../utils/dugnadUtils';

// Returntype for hooken: liste, lastestatus, feil og refresh-funksjon
interface UseDugnadsResult {
    dugnads: Dugnad[];
    loading: boolean;
    error: string | null;
    refresh: () => Promise<void>;
}

// Hook for å hente, filtrere og sortere dugnader
export const useDugnads = (search: string = ''): UseDugnadsResult => {
    const [allDugnads, setAllDugnads] = useState<Dugnad[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    // Henter dugnader fra Firestore og oppdaterer lokal state
    const fetchDugnads = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await getDugnads();
            setAllDugnads(data);
        } catch (e: any) {
            console.error('Feil ved henting av dugnader', e);
            setError('Kunne ikke hente dugnader.');
        } finally {
            setLoading(false);
        }
    }, []);

    // Hent dugnader ved mount og når fetchDugnads endres
    useEffect(() => {
        fetchDugnads();
    }, [fetchDugnads]);

    // Filtrer og sorter dugnader basert på søketerm
    const filteredAndSorted = useMemo(() => {
        const filtered = filterDugnadsBySearch(allDugnads, search);
        return sortDugnadsForList(filtered);
    }, [allDugnads, search]);

    // Returner dugnader, lastestatus, feil og refresh-funksjon
    return {
        dugnads: filteredAndSorted,
        loading,
        error,
        refresh: fetchDugnads,
    };
};
