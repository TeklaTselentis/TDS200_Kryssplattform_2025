const Colors = {
    primary: '#2563eb',
    primaryLight: '#60a5fa',
    primaryDark: '#1d4ed8',

    background: '#f9fafb',
    card: '#ffffff',
    border: '#e5e7eb',

    text: '#111827',
    textMuted: '#6b7280',

    success: '#16a34a',
    warning: '#f59e0b',
    danger: '#dc2626',

    chipBlue: '#dbeafe',
    chipGreen: '#dcfce7',
    chipGray: '#e5e7eb',
};

export default Colors;
