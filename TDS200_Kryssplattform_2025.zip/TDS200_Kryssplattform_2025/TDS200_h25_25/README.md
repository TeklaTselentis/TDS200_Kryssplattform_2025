# DugnadHub — Kryssplattform app (TDS200 H2025)

En React Native / Expo-app for å organisere og delta på dugnader i nærmiljøet.

## Funksjonalitet
- Opprett og administrer dugnader med dato, sted og oppgaver
- Meld deg på og av dugnader
- Kart-visning av dugnader i nærheten
- Kommentarer og likes på dugnader
- Favoritter
- Autentisering med Firebase Auth
- Admin-panel for administrasjon

## Oppsett

### 1. Klone prosjektet
```bash
git clone <repo-url>
cd TDS200_h25_25
```

### 2. Installer avhengigheter
```bash
npm install
```

### 3. Sett opp Firebase
Opprett et Firebase-prosjekt på [console.firebase.google.com](https://console.firebase.google.com) og aktiver Firestore, Authentication og Storage.

```bash
cp .env.example .env
```

Åpne `.env` og fyll inn dine Firebase-verdier.

### 4. Start appen
```bash
npx expo start
```

## Krav
- Node.js 18+
- Expo Go-appen på mobil, eller iOS/Android-simulator
