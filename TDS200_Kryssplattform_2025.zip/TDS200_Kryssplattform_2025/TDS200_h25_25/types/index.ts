
// Brukerrolle: frivillig (standard) eller arrangør (kan opprette/administrere dugnader)
export type UserRole = 'volunteer' | 'organizer';

// Grunndata for en innlogget bruker
export interface User {
    id: string;
    email: string;
    name: string;
    role: UserRole;
    createdAt: Date;
    profileImage?: string;
}

// Modell for dugnad
export interface Dugnad {
    id: string;
    title: string;
    description: string;
    category: string;
    location: string;
    lat: number;
    lng: number;
    address: string;
    date: Date;
    startTime: string;
    endTime: string;
    tasks: string[];
    volunteersNeeded: number;
    volunteersRegistered: number;
    organizerId: string;
    organizerName: string;
    organizerEmail: string;
    images: string[];
    createdAt: Date;
    status: 'upcoming' | 'ongoing' | 'completed' | 'cancelled';
    latitude?: number | null;
    longitude?: number | null;
}

// Registreringsmodell for dugnader
export interface Registration {
    id: string;
    dugnadId: string;
    userId: string;
    userName: string;
    userEmail: string;
    registeredAt: Date;
    status: 'registered' | 'withdrawn';
}

// Kommentarmodell for dugnader
export interface Comment {
    id: string;
    dugnadId: string;
    userId: string;
    userName: string;
    content: string;
    createdAt: Date;
    likes: number;
    likedBy: string[];
}

// Favorittmodell for dugnader
export interface Favorite {
    id: string;
    dugnadId: string;
    userId: string;
    createdAt: Date;
}

// Brukerstatistikkmodell
export interface UserStats {
    totalParticipations: number;
    upcomingDugnads: number;
    completedDugnads: number;
    ongoingDugnads: number;
    favorites: number;
}
