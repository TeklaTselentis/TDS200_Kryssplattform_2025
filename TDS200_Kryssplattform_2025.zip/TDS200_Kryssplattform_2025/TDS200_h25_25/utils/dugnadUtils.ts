import type { Dugnad } from '../types';

// Beregner den faktiske statusen til en dugnad basert på dato og tid
export const getComputedStatus = (
    dugnad: Dugnad,
    now: Date = new Date()
): Dugnad['status'] => {
    // Avlyste dugnader har alltid status 'cancelled'
    if (dugnad.status === 'cancelled') return 'cancelled';

    // Beregn status basert på dato og tid
    const date = new Date(dugnad.date);
    const [startHour, startMinute] = dugnad.startTime.split(':').map(Number);
    const [endHour, endMinute] = dugnad.endTime.split(':').map(Number);

    // Sett start- og sluttidspunkter for dugnaden
    const start = new Date(date);
    start.setHours(startHour || 0, startMinute || 0, 0, 0);

    const end = new Date(date);
    end.setHours(endHour || 0, endMinute || 0, 0, 0);

    // Bestem status basert på nåværende tid
    if (now < start) return 'upcoming';
    if (now > end) return 'completed';
    return 'ongoing';
};

// Formaterer dugnadsdato og -tid til en lesbar streng
export const formatDugnadDateTime = (dugnad: Dugnad): string => {
    const d = new Date(dugnad.date);
    const weekday = d
        .toLocaleDateString('nb-NO', { weekday: 'short' })
        .replace('.', '');
    const dayMonth = d.toLocaleDateString('nb-NO', {
        day: '2-digit',
        month: 'short',
    });

    return `${weekday} ${dayMonth}, ${dugnad.startTime}–${dugnad.endTime}`;
};

// Filtrer dugnader basert på søketerm i tittel, beskrivelse, kategori, sted eller adresse
export const filterDugnadsBySearch = (
    dugnads: Dugnad[],
    search: string
): Dugnad[] => {
    if (!search.trim()) return dugnads;

    const q = search.toLowerCase();

    return dugnads.filter((d) => {
        return (
            d.title.toLowerCase().includes(q) ||
            d.description.toLowerCase().includes(q) ||
            d.category.toLowerCase().includes(q) ||
            d.location.toLowerCase().includes(q) ||
            d.address.toLowerCase().includes(q)
        );
    });
};

// Sorter dugnader for listevisning: kommende først, deretter pågående, så fullførte og avlyste
export const sortDugnadsForList = (dugnads: Dugnad[]): Dugnad[] => {
    const now = new Date();

    const score = (d: Dugnad): number => {
        const status = getComputedStatus(d, now);
        const timeValue = new Date(d.date).getTime();

        switch (status) {
            case 'upcoming':
                return timeValue; // jo nærmere nå, jo lavere score
            case 'ongoing':
                return timeValue + 1_000_000_000; // etter upcoming
            case 'completed':
                return timeValue + 2_000_000_000; // etter ongoing
            case 'cancelled':
            default:
                return timeValue + 3_000_000_000; // til slutt
        }
    };
    return [...dugnads].sort((a, b) => score(a) - score(b));
};
