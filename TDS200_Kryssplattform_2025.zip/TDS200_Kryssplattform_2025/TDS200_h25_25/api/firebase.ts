import {
  collection,
  doc,
  addDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  serverTimestamp,
  orderBy,
  increment,
  setDoc,
} from 'firebase/firestore';
import { db } from '../firebaseConfig';
import type { Dugnad, User } from '../types';


// Input- og datamodeller
export interface CreateDugnadInput {
  title: string;
  description: string;
  category: string;
  location: string;
  address: string;
  date: Date;
  startTime: string;
  endTime: string;
  tasks: string[];
  volunteersNeeded: number;
  organizerId: string;
  organizerName: string;
  organizerEmail: string;
  images: string[];
  latitude: number | null;
  longitude: number | null;
}

// Modell for registreringer/påmeldinger
export interface Registration {
  id: string;
  dugnadId: string;
  userId: string;
  userName: string;
  userEmail: string;
  status: 'registered' | 'cancelled' | string;
  createdAt?: Date;
}

// Modell for favoritter
export interface Favorite {
  id: string;
  dugnadId: string;
  userId: string;
  createdAt?: Date;
}

//
export interface DugnadComment {
  id: string;
  dugnadId: string;
  userId: string;
  userName: string;
  text: string;
  createdAt: Date;
  likeCount: number;
}


// Konverterer Firestore timestamp -> vanlig JS Date
function mapTimestampToDate(value: any): Date | any {
  if (value && typeof value === 'object' && 'toDate' in value) {
    return value.toDate();
  }
  return value;
}

// Mapper dugnad-dokument til korrekt TypeScript-type
function mapDugnadDoc(id: string, data: any): Dugnad {
  return {
    id,
    ...data,
    date: mapTimestampToDate(data.date), // Sikrer riktig datotype
  } as Dugnad;
}

// Mapper registrering til TS-objekt
function mapRegistrationDoc(id: string, data: any): Registration {
  return {
    id,
    dugnadId: data.dugnadId,
    userId: data.userId,
    userName: data.userName,
    userEmail: data.userEmail,
    status: data.status ?? 'registered',
    createdAt: mapTimestampToDate(data.createdAt),
  };
}

// Mapper favoritt til TS-objekt
function mapFavoriteDoc(id: string, data: any): Favorite {
  return {
    id,
    dugnadId: data.dugnadId,
    userId: data.userId,
    createdAt: mapTimestampToDate(data.createdAt),
  };
}


// Oppretter en ny dugnad
export async function createDugnad(
  input: CreateDugnadInput
): Promise<Dugnad> {
  const ref = await addDoc(collection(db, 'dugnads'), {
    ...input,
    volunteersRegistered: 0,
    createdAt: serverTimestamp(),
  });

  const snap = await getDoc(ref);
  const data = snap.data()!;
  return mapDugnadDoc(ref.id, data);
}

// Oppdaterer dugnad
export async function updateDugnad(
  id: string,
  input: CreateDugnadInput
): Promise<void> {
  const ref = doc(db, 'dugnads', id);
  await updateDoc(ref, {
    ...input,
    updatedAt: serverTimestamp(),
  });
}

// Henter alle dugnader
export async function getDugnads(): Promise<Dugnad[]> {
  const snap = await getDocs(collection(db, 'dugnads'));
  return snap.docs.map((d) => mapDugnadDoc(d.id, d.data()));
}

// Henter én dugnad
export async function getDugnadById(
  id: string
): Promise<Dugnad | null> {
  const ref = doc(db, 'dugnads', id);
  const snap = await getDoc(ref);
  if (!snap.exists()) return null;
  return mapDugnadDoc(snap.id, snap.data());
}

// Sletter dugnad
export async function deleteDugnad(args: { dugnadId: string }): Promise<void> {
  const { dugnadId } = args;
  const ref = doc(db, 'dugnads', dugnadId);
  await deleteDoc(ref);
}

// Registrer bruker til dugnad
export async function registerForDugnad(args: {
  dugnadId: string;
  userId: string;
  userName: string;
  userEmail: string;
}): Promise<void> {
  const { dugnadId, userId, userName, userEmail } = args;

  // Sjekk om bruker allerede er registrert
  const q = query(
    collection(db, 'registrations'),
    where('dugnadId', '==', dugnadId),
    where('userId', '==', userId)
  );
  const snap = await getDocs(q);

  if (snap.empty) {
      // Ny registrering
    await addDoc(collection(db, 'registrations'), {
      dugnadId,
      userId,
      userName,
      userEmail,
      status: 'registered',
      createdAt: serverTimestamp(),
    });
  } else {
      // Oppdater status dersom brukeren registrerer seg på nytt
    await updateDoc(snap.docs[0].ref, {
      status: 'registered',
      updatedAt: serverTimestamp(),
    });
  }
}

// Avregistrering
export async function unregisterFromDugnad(args: {
  dugnadId: string;
  userId: string;
}): Promise<void> {
  const { dugnadId, userId } = args;

  const q = query(
    collection(db, 'registrations'),
    where('dugnadId', '==', dugnadId),
    where('userId', '==', userId)
  );
  const snap = await getDocs(q);

  if (snap.empty) return;

  await updateDoc(snap.docs[0].ref, {
    status: 'cancelled',
    updatedAt: serverTimestamp(),
  });
}

// Hent registreringer for én bruker
export async function getRegistrationsForUser(
  userId: string
): Promise<Registration[]> {
  const q = query(
    collection(db, 'registrations'),
    where('userId', '==', userId)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => mapRegistrationDoc(d.id, d.data()));
}

// Hent alle registreringer
export async function getAllRegistrations(): Promise<Registration[]> {
  const snap = await getDocs(collection(db, 'registrations'));
  return snap.docs.map((d) => mapRegistrationDoc(d.id, d.data()));
}

// Hent alle registreringer for én dugnad
export async function getRegistrationsForDugnad(dugnadId: string) {
  const q = query(
    collection(db, 'registrations'),
    where('dugnadId', '==', dugnadId)
  );

  const snapshot = await getDocs(q);

  return snapshot.docs
    .map((doc) => ({
      id: doc.id,
      ...(doc.data() as any),
    }))
    .filter((r) => r.status === 'registered');
}

// Legg til / fjern favoritt
export async function toggleFavorite(args: {
  dugnadId: string;
  userId: string;
}): Promise<void> {
  const { dugnadId, userId } = args;

  const q = query(
    collection(db, 'favorites'),
    where('dugnadId', '==', dugnadId),
    where('userId', '==', userId)
  );
  const snap = await getDocs(q);

  if (snap.empty) {
    // Legg til favoritt
    await addDoc(collection(db, 'favorites'), {
      dugnadId,
      userId,
      createdAt: serverTimestamp(),
    });
  } else {
    // Fjern favoritt
    await deleteDoc(snap.docs[0].ref);
  }
}

// Hent favoritter til en bruker
export async function getFavoritesForUser(
  userId: string
): Promise<Favorite[]> {
  const q = query(
    collection(db, 'favorites'),
    where('userId', '==', userId)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => mapFavoriteDoc(d.id, d.data()));
}

// Hent alle brukere
export async function getAllUsers(): Promise<User[]> {
  const snap = await getDocs(collection(db, 'users'));
  return snap.docs.map(
    (d) =>
    ({
      id: d.id,
      ...d.data(),
    } as User)
  );
}

// Legg til kommentar
export async function addDugnadComment(args: {
  dugnadId: string;
  userId: string;
  userName: string;
  text: string;
}): Promise<DugnadComment> {
  const { dugnadId, userId, userName, text } = args;
   
  // Opprett kommentaren
  const ref = await addDoc(collection(db, 'comments'), {
    dugnadId,
    userId,
    userName,
    text,
    likeCount: 0,
    createdAt: serverTimestamp(),
  });

  const snap = await getDoc(ref);
  const data = snap.data()!;
  return {
    id: ref.id,
    dugnadId,
    userId,
    userName,
    text,
    likeCount: data.likeCount ?? 0,
    createdAt: mapTimestampToDate(data.createdAt),
  };
}

// Hent alle kommentarer på en dugnad
export async function getDugnadComments(
  dugnadId: string
): Promise<DugnadComment[]> {
  const q = query(
    collection(db, 'comments'),
    where('dugnadId', '==', dugnadId)
  );

  const snap = await getDocs(q);

  const list = snap.docs.map((d) => {
    const data = d.data() as any;
    const createdAt = mapTimestampToDate(data.createdAt);
    return {
      id: d.id,
      dugnadId: data.dugnadId,
      userId: data.userId,
      userName: data.userName,
      text: data.text,
      likeCount: data.likeCount ?? 0,
      createdAt,
    };
  });

  // Sorter nyeste først
  return list.sort((a, b) => {
    const aTime =
      a.createdAt instanceof Date
        ? a.createdAt.getTime()
        : new Date(a.createdAt).getTime();
    const bTime =
      b.createdAt instanceof Date
        ? b.createdAt.getTime()
        : new Date(b.createdAt).getTime();
    return bTime - aTime;
  });
}


// Slett kommentar
export async function deleteDugnadComment(args: {
  commentId: string;
  userId: string;
}): Promise<void> {
  const { commentId, userId } = args;
  const ref = doc(db, 'comments', commentId);

  const snap = await getDoc(ref);
  if (!snap.exists()) return;

  const data = snap.data() as any;
  if (data.userId !== userId) {
    throw new Error('Kan ikke slette kommentar som ikke er din');
  }

  await deleteDoc(ref);
}

// Hent alle likes brukeren har gitt på en spesifikk dugnad
export async function getDugnadCommentLikesForUser(args: {
  dugnadId: string;
  userId: string;
}): Promise<string[]> {
  const { dugnadId, userId } = args;

  const q = query(
    collection(db, 'commentLikes'),
    where('userId', '==', userId)
  );

  const snap = await getDocs(q);

  return snap.docs
    .map((d) => d.data() as any)
    .filter((data) => data.dugnadId === dugnadId)
    .map((data) => data.commentId as string);
}

// Toggle like (liker eller fjerner like)
export async function toggleDugnadCommentLike(args: {
  commentId: string;
  dugnadId: string;
  userId: string;
}): Promise<void> {
  const { commentId, dugnadId, userId } = args;
    
  // Like dokument-ID basert på kombinasjonen
  const likeRef = doc(db, 'commentLikes', `${userId}_${commentId}`);
  const commentRef = doc(db, 'comments', commentId);
  const likeSnap = await getDoc(likeRef);


  if (likeSnap.exists()) {
    // Fjern like
    await deleteDoc(likeRef);
    // Oppdater likeCount
    await updateDoc(commentRef, {
      likeCount: increment(-1),
    });
  } else {
    // Legg til like
    await setDoc(likeRef, {
      commentId,
      dugnadId,
      userId,
      createdAt: serverTimestamp(),
    });
    // Øke likeCount
    await updateDoc(commentRef, {
      likeCount: increment(1),
    });
  }
}
