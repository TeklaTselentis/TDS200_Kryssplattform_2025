import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
  Auth
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp, Firestore } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
import { User, UserRole } from '../types';

// Tvinger auth og db til korrekte Firebase-typer
const typedAuth = auth as Auth;
const typedDb = db as Firestore;

// Funksjon som konverterer en FirebaseUser til appens eget User-objekt
// Oppretter dokument i Firestore hvis det ikke finnes fra før
const convertFirebaseUser = async (firebaseUser: FirebaseUser, role?: UserRole): Promise<User> => {
  // Referanse til brukerens dokument i Firestore
  const userRef = doc(typedDb, 'users', firebaseUser.uid);
  const snap = await getDoc(userRef);

  // Hvis dokument ikke finnes → opprett ny bruker i Firestore
  if (!snap.exists()) {
    const userData: User = {
      id: firebaseUser.uid,
      email: firebaseUser.email || '',
      name: firebaseUser.displayName || firebaseUser.email || 'Ukjent bruker',
      role: role || 'volunteer',
      createdAt: new Date(),
    };

    // Lagre bruker i Firestore med servergenerert timestamp
    await setDoc(userRef, {
      ...userData,
      createdAt: serverTimestamp(),
    });

    return userData;
  }

  // Hvis dokument eksisterer -> hent data og konverter
  const data = snap.data();

  // Returner User-objekt
  return {
    id: firebaseUser.uid,
    email: data.email,
    name: data.name,
    role: data.role as UserRole,
    createdAt: data.createdAt?.toDate?.() || new Date(),
  };
};

// Registrerer en ny bruker med e-post og passord
export const register = async (
  email: string,
  password: string,
  name: string,
  role: UserRole
): Promise<User> => {
  const cred = await createUserWithEmailAndPassword(typedAuth, email, password);
  const user = await convertFirebaseUser(cred.user, role);
  return user;
};

// Logger inn en eksisterende bruker
export const login = async (
  email: string,
  password: string
): Promise<User> => {
  const cred = await signInWithEmailAndPassword(typedAuth, email, password);
  const user = await convertFirebaseUser(cred.user);
  return user;
};

// Logger ut brukeren
export const logout = async (): Promise<void> => { await signOut(typedAuth); };


// Lytter på om brukeren er innlogget eller utlogget
// callback blir kalt hver gang innloggingsstatus endrer seg
export const subscribeToAuth = (
  callback: (user: User | null) => void
): (() => void) => {
  return onAuthStateChanged(typedAuth, async (firebaseUser) => {
    if (!firebaseUser) {
      callback(null);
      return;
    }

    // Konverter FirebaseUser -> User-objekt
    const user = await convertFirebaseUser(firebaseUser);
    callback(user);
  });
};