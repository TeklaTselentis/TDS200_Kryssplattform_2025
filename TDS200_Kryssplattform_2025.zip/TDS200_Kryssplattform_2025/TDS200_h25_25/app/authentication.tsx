import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import Colors from '../constants/Colors';
import { useAuth } from '../providers/authctx';
import { Button } from '../components/ui/Button';
import type { UserRole } from '../types';

// Hovedkomponenten for autentiseringsskjermen (logg inn / registrer)
export default function AuthenticationScreen() {
  const { user, loginWithEmail, registerWithEmail, loading } = useAuth();
  const router = useRouter();
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>('volunteer');
  const [error, setError] = useState<string | null>(null);

  // Hvis bruker er logget inn, naviger til hovedappen
  useEffect(() => {
    if (user) {
      router.replace('/(app)');
    }
  }, [user]);

  // Håndter innsending av skjema for logg inn / registrer
  const handleSubmit = async () => {
    setError(null);

    const trimmedEmail = email.trim().toLowerCase();

    try {
      if (isRegister) {
        if (!name.trim()) {
          setError('Navn må fylles ut.');
          return;
        }
        if (!trimmedEmail) {
          setError('E-post må fylles ut.');
          return;
        }
        if (!pass.trim()) {
          setError('Passord må fylles ut.');
          return;
        }
        await registerWithEmail(trimmedEmail, pass, name.trim(), role);
      } else {
        if (!trimmedEmail || !pass.trim()) {
          setError('Skriv inn e-post og passord.');
          return;
        }
        await loginWithEmail(trimmedEmail, pass);
      }
    } catch (err: any) {
      setError(err?.message ?? 'Noe gikk galt ved pålogging.');
    }
  };

  // Vis lasteskjerm mens vi sjekker brukerstatus
  if (user) {
    return (
      <View style={styles.fullscreenCenter}>
        <ActivityIndicator />
      </View>
    );
  }

  // Hovedrendering av autentiseringsskjermen
  return (
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.header}>
        <Text style={styles.appName}>DugnadHub</Text>
        <Text style={styles.appTagline}>Finn og organiser dugnader i nærmiljøet</Text>
      </View>

      <View style={styles.card}>
        {/* Toggle mellom Logg inn / Registrer */}
        <View style={styles.modeSwitch}>
          <TouchableOpacity
            style={[
              styles.modeButton,
              !isRegister && styles.modeButtonActive,
            ]}
            onPress={() => setIsRegister(false)}
            disabled={!isRegister}
          >
            <Text
              style={[
                styles.modeButtonText,
                !isRegister && styles.modeButtonTextActive,
              ]}
            >
              Logg inn
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.modeButton,
              isRegister && styles.modeButtonActive,
            ]}
            onPress={() => setIsRegister(true)}
            disabled={isRegister}
          >
            <Text
              style={[
                styles.modeButtonText,
                isRegister && styles.modeButtonTextActive,
              ]}
            >
              Registrer
            </Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.subtitle}>
          {isRegister ? 'Opprett ny bruker' : 'Logg inn for å fortsette'}
        </Text>

        {isRegister && (
          <>
            <Text style={styles.label}>Navn</Text>
            <TextInput
              style={styles.input}
              value={name}
              onChangeText={setName}
              placeholder="Ditt navn"
            />
          </>
        )}

        <Text style={styles.label}>E-post</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="email-address"
          textContentType="emailAddress"
          autoComplete="email"
          placeholder="din@epost.no"
        />

        <Text style={styles.label}>Passord</Text>
        <TextInput
          style={styles.input}
          value={pass}
          onChangeText={setPass}
          secureTextEntry
          placeholder="••••••••"
        />

        {isRegister && (
          <>
            <Text style={styles.label}>Rolle</Text>
            <View style={styles.roleRow}>
              <RoleChip
                label="Frivillig"
                selected={role === 'volunteer'}
                onPress={() => setRole('volunteer')}
              />
              <RoleChip
                label="Arrangør"
                selected={role === 'organizer'}
                onPress={() => setRole('organizer')}
              />
            </View>
            <Text style={styles.roleHint}>
              Arrangør kan opprette og administrere dugnader.
            </Text>
          </>
        )}

        {error && <Text style={styles.error}>{error}</Text>}

        <Button
          title={isRegister ? 'Registrer bruker' : 'Logg inn'}
          onPress={handleSubmit}
          loading={loading}
          style={styles.primaryButton}
        />

        <TouchableOpacity
          onPress={() => setIsRegister(v => !v)}
          style={styles.toggleRow}
        >
          <Text style={styles.toggleText}>
            {isRegister
              ? 'Har du allerede en konto? '
              : 'Har du ikke konto ennå? '}
          </Text>
          <Text style={styles.toggleTextLink}>
            {isRegister ? 'Logg inn' : 'Registrer deg'}
          </Text>
        </TouchableOpacity>

        {loading && (
          <View style={styles.loadingRow}>
            <ActivityIndicator />
            <Text style={styles.loadingText}>Håndterer pålogging…</Text>
          </View>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

function RoleChip({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.roleChip, selected && styles.roleChipSelected]}
    >
      <Text
        style={[
          styles.roleChipText,
          selected && styles.roleChipTextSelected,
        ]}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// Styling
const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 24,
    justifyContent: 'center',
  },
  fullscreenCenter: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.background,
  },
  header: {
    marginBottom: 16,
    alignItems: 'center',
  },
  appName: {
    fontSize: 32,
    fontWeight: '800',
    color: Colors.primary,
    letterSpacing: 0.5,
  },
  appTagline: {
    marginTop: 4,
    fontSize: 13,
    color: Colors.textMuted,
  },
  card: {
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  modeSwitch: {
    flexDirection: 'row',
    backgroundColor: Colors.background,
    borderRadius: 999,
    padding: 3,
    marginBottom: 16,
  },
  modeButton: {
    flex: 1,
    borderRadius: 999,
    paddingVertical: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modeButtonActive: {
    backgroundColor: Colors.primary,
  },
  modeButtonText: {
    fontSize: 14,
    color: Colors.textMuted,
    fontWeight: '500',
  },
  modeButtonTextActive: {
    color: '#fff',
  },
  subtitle: {
    fontSize: 14,
    color: Colors.textMuted,
    marginBottom: 12,
  },
  label: {
    fontSize: 13,
    marginTop: 10,
    marginBottom: 4,
    color: Colors.text,
  },
  input: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#fff',
    fontSize: 14,
  },
  error: {
    marginTop: 8,
    fontSize: 12,
    color: Colors.danger,
  },
  primaryButton: {
    marginTop: 18,
  },
  toggleRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 12,
  },
  toggleText: {
    fontSize: 13,
    color: Colors.textMuted,
  },
  toggleTextLink: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '600',
  },
  loadingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  loadingText: {
    marginLeft: 8,
    fontSize: 12,
    color: Colors.textMuted,
  },
  roleRow: {
    flexDirection: 'row',
    marginTop: 4,
  },
  roleChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: Colors.border,
    marginRight: 8,
  },
  roleChipSelected: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  roleChipText: {
    fontSize: 12,
    color: Colors.text,
  },
  roleChipTextSelected: {
    color: '#fff',
    fontWeight: '600',
  },
  roleHint: {
    marginTop: 4,
    fontSize: 11,
    color: Colors.textMuted,
  },
});
