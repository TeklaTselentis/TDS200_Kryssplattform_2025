import React from 'react';
import { Stack } from 'expo-router';

// Definerer appens rotlayout (Stack) uten header
export default function AppLayout() {
    return (
        <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            <Stack.Screen name="post-details/[id]" options={{ headerShown: false }} />
            <Stack.Screen name="new" options={{ headerShown: false }} />
        </Stack>
    );
}