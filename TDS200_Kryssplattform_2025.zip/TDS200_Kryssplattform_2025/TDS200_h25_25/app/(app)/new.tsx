import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import Colors from '../../constants/Colors';
import HomeHeader from '../../components/HomeHeader';
import { CreateDugnadForm } from '../../components/CreateDugnadForm';

//Bottombar tilgjengelig på opprett ny dugnad-skjermen
const bottomTabs = [
  { 
    key: 'home', 
    label: 'Hjem', 
    icon: 'home-outline' as const, route: '/' },
  {
    key: 'activity',
    label: 'Mine dugnader',
    icon: 'heart-outline' as const,
    route: '/activity',
  },
  { key: 'map', 
    label: 'Kart', 
    icon: 'map-outline' as const, 
    route: '/map' },
];

// Hovedkomponenten for opprettelse av ny dugnad
export default function NewDugnadScreen() {
  const router = useRouter();

  return (
    <View style={styles.root}>
      <HomeHeader />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: 120 }}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.pageHeader}>
          <Text style={styles.pageTitle}>Ny dugnad</Text>
          <Text style={styles.pageSubtitle}>
            Opprett en ny dugnad i nærmiljøet.
          </Text>
        </View>

        <CreateDugnadForm />
      </ScrollView>

      {/* Egen bottom bar (kun på denne skjermen) */}
      <View style={styles.bottomBar}>
        {bottomTabs.map((tab) => (
          <TouchableOpacity
            key={tab.key}
            style={styles.tabButton}
            onPress={() => router.push(tab.route as any)}
            activeOpacity={0.8}
          >
            <Ionicons name={tab.icon} size={22} color="#111827" />
            <Text style={styles.tabLabel}>{tab.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// Styling
const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scroll: {
    flex: 1,
  },
  pageHeader: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  pageTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  pageSubtitle: {
    fontSize: 14,
    color: Colors.textMuted,
  },
  bottomBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingTop: 9,
    paddingBottom: Platform.OS === 'ios' ? 20 : 12,
    paddingHorizontal: 24,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: Platform.OS === 'ios' ? 72 : 64,
  },
  tabButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabLabel: {
    marginTop: 2,
    fontSize: 11,

  },
});
