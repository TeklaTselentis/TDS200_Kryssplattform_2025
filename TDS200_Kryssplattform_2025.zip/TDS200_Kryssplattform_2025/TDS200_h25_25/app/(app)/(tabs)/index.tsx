import React, { useMemo, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  SafeAreaView,
  ScrollView,
  ActivityIndicator,
  Pressable,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Colors from '../../../constants/Colors';
import { useDugnads } from '../../../hooks/useDugnads';
import { DugnadList } from '../../../components/DugnadList';
import type { Dugnad } from '../../../types';
import { useRouter } from 'expo-router';
import { useAuth } from '../../../providers/authctx';
import { getFavoritesForUser, toggleFavorite } from '../../../api/firebase';
import { getComputedStatus } from '../../../utils/dugnadUtils';

// Kategorier for dugnader som brukes i filteret
const CATEGORIES = [
  'Park og natur',
  'Miljø',
  'Vedlikehold',
  'Sosialt',
  'Barn og familie',
  'Sport og aktivitet',
  'Kultur',
  'Annet',
];

// Type for statusfilter
type StatusFilter = 'alle' | 'kommende' | 'pågående' | 'fullført';

// Mulige statusvalg for filteret
const STATUS_OPTIONS: { value: StatusFilter; label: string }[] = [
  { value: 'alle', label: 'Alle' },
  { value: 'kommende', label: 'Kommende' },
  { value: 'pågående', label: 'Pågående' },
  { value: 'fullført', label: 'Fullført' },
];

// Hovedskjerm for appen som viser liste over dugnader
export default function HomeScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const role = user?.role ?? 'volunteer';
  const isOrganizer = role === 'organizer';
  const { dugnads, loading, error } = useDugnads();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('kommende');
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);
  const [favoritesLoading, setFavoritesLoading] = useState(false);
  const [showCategoryMenu, setShowCategoryMenu] = useState(false);
  const [showStatusMenu, setShowStatusMenu] = useState(false);

  // Hent favoritter når bruker endres (login/logout)
  useEffect(() => {
    if (!user) {
      setFavoriteIds([]);
      return;
    }

    let cancelled = false;

    const loadFavorites = async () => {
      try {
        setFavoritesLoading(true);
        const favs = await getFavoritesForUser(user.id);
        if (!cancelled) {
          setFavoriteIds(favs.map((f: any) => f.dugnadId));
        }
      } catch (e) {
        console.error('Feil ved henting av favoritter', e);
      } finally {
        if (!cancelled) {
          setFavoritesLoading(false);
        }
      }
    };

    loadFavorites();

    return () => {
      cancelled = true;
    };
  }, [user]);


  // Utleder filtrert liste basert på søk, kategori og status
  const filteredDugnads: Dugnad[] = useMemo(() => {
    return dugnads
      .filter((d) =>
        searchQuery.trim().length === 0
          ? true
          : d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          d.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
      .filter((d) =>
        categoryFilter ? d.category === categoryFilter : true
      )
      .filter((d) => {
        if (statusFilter === 'alle') return true;

        const status = getComputedStatus(d);
        if (statusFilter === 'kommende') return status === 'upcoming';
        if (statusFilter === 'pågående') return status === 'ongoing';
        if (statusFilter === 'fullført') return status === 'completed';
        return true;
      });
  }, [dugnads, searchQuery, categoryFilter, statusFilter]);

  // Åpner detaljvisning for valgt dugnad
  const handleSelectDugnad = (dugnad: Dugnad) => {
    router.push({
      pathname: '/post-details/[id]',
      params: { id: dugnad.id },
    });
  };

  // Håndterer favorisering/avfavorisering av dugnad
  const handleToggleFavorite = async (dugnad: Dugnad) => {
    if (!user) {
      return;
    }

    const isFav = favoriteIds.includes(dugnad.id);


    setFavoriteIds((prev) =>
      isFav ? prev.filter((id) => id !== dugnad.id) : [...prev, dugnad.id]
    );

    try {
      await toggleFavorite({ dugnadId: dugnad.id, userId: user.id });
    } catch (e) {
      console.error('Feil ved favorisering fra hjem-skjerm', e);
      setFavoriteIds((prev) =>
        isFav ? [...prev, dugnad.id] : prev.filter((id) => id !== dugnad.id)
      );
    }
  };

  // Navigerer til opprettelse av ny dugnad (kun arrangør)
  const handleCreatePress = () => {
    if (!isOrganizer) return;
    router.push('/(app)/new' as any);
  };


  // Nåværende label for statusfilter
  const currentStatusLabel =
    STATUS_OPTIONS.find((o) => o.value === statusFilter)?.label ?? 'Alle';
  
    // Hovedinnhold (overskrift, søk, filtre, liste)
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        {/* Tittel + ny-knapp (kun arrangør) */}
        <View style={styles.headerSection}>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>Dugnader i ditt område</Text>
            <Text style={styles.headerSubtitle}>
              Bli med på lokale dugnader og bidra i nærmiljøet
            </Text>
          </View>

          {isOrganizer && (
            <Pressable
              style={styles.newButton}
              onPress={handleCreatePress}
            >
              <Text style={styles.newButtonText}>Ny</Text>
              <Ionicons
                name="add"
                size={18}
                color="#111827"
                style={{ marginLeft: 4 }}
              />
            </Pressable>
          )}
        </View>

        {/* Søkefelt */}
        <View style={styles.searchWrapper}>
          <View style={styles.searchInputWrapper}>
            <Ionicons
              name="search-outline"
              size={18}
              color={Colors.textMuted}
              style={{ marginRight: 8 }}
            />
            <TextInput
              style={styles.searchInput}
              placeholder="Søk etter dugnader..."
              placeholderTextColor={Colors.textMuted}
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </View>

        {/* Filter-knapper (kategori + status) */}
        <View style={styles.filterRow}>
          <Pressable
            style={styles.filterPill}
            onPress={() => {
              setShowCategoryMenu((prev) => !prev);
              setShowStatusMenu(false);
            }}
          >
            <Text style={styles.filterText}>
              {categoryFilter ?? 'Alle kategorier'}
            </Text>
            <Ionicons
              name="chevron-down-outline"
              size={16}
              color={Colors.textMuted}
            />
          </Pressable>

          <View style={styles.filterSpacer} />

          <Pressable
            style={styles.filterPill}
            onPress={() => {
              setShowStatusMenu((prev) => !prev);
              setShowCategoryMenu(false);
            }}
          >
            <Text style={styles.filterText}>{currentStatusLabel}</Text>
            <Ionicons
              name="chevron-down-outline"
              size={16}
              color={Colors.textMuted}
            />
          </Pressable>
        </View>

        {/* Dropdown for kategori */}
        {showCategoryMenu && (
          <View style={styles.dropdownContainerLeft}>
            <Pressable
              style={[
                styles.dropdownItem,
                !categoryFilter && styles.dropdownItemActive,
              ]}
              onPress={() => {
                setCategoryFilter(null);
                setShowCategoryMenu(false);
              }}
            >
              <Text
                style={[
                  styles.dropdownItemText,
                  !categoryFilter && styles.dropdownItemTextActive,
                ]}
              >
                Alle kategorier
              </Text>
              {!categoryFilter && (
                <Ionicons name="checkmark" size={16} color="#111827" />
              )}
            </Pressable>

            {CATEGORIES.map((cat) => {
              const isActive = categoryFilter === cat;
              return (
                <Pressable
                  key={cat}
                  style={[
                    styles.dropdownItem,
                    isActive && styles.dropdownItemActive,
                  ]}
                  onPress={() => {
                    setCategoryFilter(cat);
                    setShowCategoryMenu(false);
                  }}
                >
                  <Text
                    style={[
                      styles.dropdownItemText,
                      isActive && styles.dropdownItemTextActive,
                    ]}
                  >
                    {cat}
                  </Text>
                  {isActive && (
                    <Ionicons name="checkmark" size={16} color="#111827" />
                  )}
                </Pressable>
              );
            })}
          </View>
        )}

        {/* Dropdown for status */}
        {showStatusMenu && (
          <View style={styles.dropdownContainerRight}>
            {STATUS_OPTIONS.map((opt) => {
              const isActive = statusFilter === opt.value;
              return (
                <Pressable
                  key={opt.value}
                  style={[
                    styles.dropdownItem,
                    isActive && styles.dropdownItemActive,
                  ]}
                  onPress={() => {
                    setStatusFilter(opt.value);
                    setShowStatusMenu(false);
                  }}
                >
                  <Text
                    style={[
                      styles.dropdownItemText,
                      isActive && styles.dropdownItemTextActive,
                    ]}
                  >
                    {opt.label}
                  </Text>
                  {isActive && (
                    <Ionicons name="checkmark" size={16} color="#111827" />
                  )}
                </Pressable>
              );
            })}
          </View>
        )}

        {loading && (
          <View style={styles.loading}>
            <ActivityIndicator />
          </View>
        )}

        {error && (
          <Text style={styles.errorText}>
            Klarte ikke å laste dugnader.
          </Text>
        )}

        <View style={styles.listWrapper}>
          <DugnadList
            dugnads={filteredDugnads}
            onSelect={handleSelectDugnad}
            favorites={favoriteIds}
            onToggleFavorite={handleToggleFavorite}
            selectedCategory={categoryFilter}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// Styling
const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  container: {
    flex: 1,
  },
  content: {
    paddingTop: 16,
    paddingBottom: 24,
  },

  headerSection: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 13,
    color: Colors.textMuted,
  },
  newButton: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 999,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginLeft: 12,
  },
  newButtonText: {
    fontSize: 13,
    fontWeight: '500',
    color: '#111827',
  },

  searchWrapper: {
    paddingHorizontal: 16,
  },
  searchInputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    backgroundColor: '#F2F2F4',
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
  },
  filterRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 8,
  },
  filterPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 999,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: '#FFFFFF',
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  filterSpacer: {
    width: 8,
  },
  filterText: {
    fontSize: 13,
    fontWeight: '500',
  },
  dropdownContainerLeft: {
    alignSelf: 'flex-start',
    marginLeft: 16,
    width: '48%',
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 4,
    overflow: 'hidden',
  },
  dropdownContainerRight: {
    alignSelf: 'flex-end',
    marginRight: 16,
    width: '48%',
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 4,
    overflow: 'hidden',
  },

  dropdownItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  dropdownItemActive: {
    backgroundColor: '#F3F4F6',
  },
  dropdownItemText: {
    fontSize: 14,
    color: '#111827',
  },
  dropdownItemTextActive: {
    fontWeight: '600',
  },
  loading: {
    paddingVertical: 16,
  },
  errorText: {
    color: 'red',
    paddingHorizontal: 16,
    paddingVertical: 8,
    fontSize: 12,
  },
  listWrapper: {
    paddingHorizontal: 16,
    paddingTop: 8,
  },
});
