import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Colors from '../../../constants/Colors';
import { useDugnads } from '../../../hooks/useDugnads';
import DugnadMap from '../../../components/DugnadMap';

// Hovedkomponenten for kartvisningen
export default function MapScreen() {
  const [search, setSearch] = useState('');
  const { dugnads, loading, error } = useDugnads(search);
  const count = dugnads.length;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Kart over dugnader</Text>
      <Text style={styles.subtitle}>
        Se dugnader som har registrert posisjon
      </Text>

      <TextInput
        style={styles.search}
        placeholder="Filtrer etter tittel, sted eller kategori..."
        value={search}
        onChangeText={setSearch}
      />


      {!loading && !error && (
        <View style={styles.mapHeaderRow}>
          <View>
            <View style={styles.mapTitleRow}>
              <Ionicons
                name="location-outline"
                size={18}
                color={Colors.primary}
                style={{ marginRight: 6 }}
              />
              <Text style={styles.mapHeaderTitle}>Kartvisning</Text>
            </View>
            <Text style={styles.mapHeaderSubtitle}>
              {count} dugnad{count === 1 ? '' : 'er'}
            </Text>
          </View>

          <View style={styles.legendRow}>
            <LegendDot color="#2563EB" label="Kommer" />
            <LegendDot color="#16A34A" label="Pågår" />
            <LegendDot color="#6B7280" label="Ferdig" />
          </View>
        </View>
      )}

      {loading && (
        <View style={styles.center}>
          <ActivityIndicator />
          <Text style={styles.centerText}>Laster dugnader...</Text>
        </View>
      )}

      {error && !loading && (
        <View style={styles.center}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      {!loading && !error && (
        <View style={{ flex: 1 }}>
          <DugnadMap dugnads={dugnads} />
        </View>
      )}
    </View>
  );
}

// Komponent for legendepunkt
const LegendDot: React.FC<{ color: string; label: string }> = ({
  color,
  label,
}) => (
  <View style={styles.legendItem}>
    <View style={[styles.legendDot, { backgroundColor: color }]} />
    <Text style={styles.legendLabel}>{label}</Text>
  </View>
);

// STyling
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
  },
  subtitle: {
    fontSize: 12,
    color: Colors.textMuted,
    marginBottom: 8,
  },
  search: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: '#fff',
    marginBottom: 8,
  },
  mapHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  mapTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  mapHeaderTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  mapHeaderSubtitle: {
    fontSize: 12,
    color: Colors.textMuted,
    marginTop: 2,
  },
  legendRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 12,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 4,
  },
  legendLabel: {
    fontSize: 12,
    color: Colors.textMuted,
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 24,
  },
  centerText: {
    marginTop: 8,
    fontSize: 13,
    color: Colors.textMuted,
  },
  errorText: {
    fontSize: 13,
    color: 'red',
  },
});


