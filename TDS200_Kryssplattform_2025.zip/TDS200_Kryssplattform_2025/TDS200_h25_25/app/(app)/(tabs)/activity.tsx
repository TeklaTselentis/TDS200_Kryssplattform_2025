import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
} from 'react-native';
import { useRouter } from 'expo-router';
import Colors from '../../../constants/Colors';
import { useAuth } from '../../../providers/authctx';
import { useUserStats } from '../../../hooks/useUserStats';
import type { Dugnad } from '../../../types';
import {
  getRegistrationsForUser,
  getFavoritesForUser,
  getDugnadById,
  toggleFavorite,
} from '../../../api/firebase';
import { getComputedStatus } from '../../../utils/dugnadUtils';
import { DugnadCard } from '../../../components/DugnadCard';

// Filtre som kan brukes i visningen
type FilterKey = 'upcoming' | 'ongoing' | 'completed' | 'favorites';

// Kombinert datastruktur for visning
interface UserDugnadItem {
  dugnad: Dugnad;
  isFavorite: boolean;
  isRegistered: boolean;
}

// Hovedkomponenten for "Mine dugnader"
export default function MyDugnadsScreen() {
  const { user } = useAuth();
  const router = useRouter();
  const { stats, loading: statsLoading } = useUserStats(user?.id);
  const [items, setItems] = useState<UserDugnadItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [mutating, setMutating] = useState(false);
  const [filter, setFilter] = useState<FilterKey>('upcoming');

  // Laster brukerens registreringer + favoritter + selve dugnadene
  useEffect(() => {
    const load = async () => {
      if (!user) {
        setItems([]);
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        // Henter registreringer og favoritter parallelt
        const [regs, favs] = await Promise.all([
          getRegistrationsForUser(user.id),
          getFavoritesForUser(user.id),
        ]);

        // Samler alle dugnad-ID-er brukeren enten har registrert eller favoritt-merket
        const allIds = Array.from(
          new Set([
            ...regs.map((r) => r.dugnadId),
            ...favs.map((f) => f.dugnadId),
          ])
        );

        // Henter dugnadsdata for hver ID
        const dugnads: Dugnad[] = [];
        for (const id of allIds) {
          const d = await getDugnadById(id);
          if (d) dugnads.push(d);
        }

        // Kombinerer informasjonen til visningsvennlig format
        const mapped: UserDugnadItem[] = dugnads.map((d) => ({
          dugnad: d,
          isFavorite: favs.some((f) => f.dugnadId === d.id),
          isRegistered: regs.some(
            (r) => r.dugnadId === d.id && r.status === 'registered'
          ),
        }));
        setItems(mapped);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user]);

  // Filtrerer dugnader basert på valgt filter
  const filtered = useMemo(() => {
    return items.filter((item) => {
      const status = getComputedStatus(item.dugnad);
      if (filter === 'favorites') return item.isFavorite;
      if (filter === 'upcoming') return status === 'upcoming';
      if (filter === 'ongoing') return status === 'ongoing';
      if (filter === 'completed') return status === 'completed';
      return true;
    });
  }, [items, filter]);

  // Oppdaterer favorittstatus for en dugnad
  const handleToggleFavorite = async (item: UserDugnadItem) => {
    if (!user) return;
    setMutating(true);
    try {
      await toggleFavorite({ dugnadId: item.dugnad.id, userId: user.id });
      setItems((prev) =>
        prev.map((p) =>
          p.dugnad.id === item.dugnad.id
            ? { ...p, isFavorite: !p.isFavorite }
            : p
        )
      );
    } finally {
      setMutating(false);
    }
  };

  // Navigerer til dugnadsdetaljer
  const handleOpenDetails = (dugnad: Dugnad) => {
    router.push(`/post-details/${dugnad.id}`);
  };

  // Hvis bruker ikke er logget inn
  if (!user) {
    return (
      <View style={styles.center}>
        <Text>Du må være logget inn for å se dine dugnader.</Text>
      </View>
    );
  }

  // Hovedinnholdet for "Mine dugnader": viser tittel, statistikk, filtreringsknapper og selve dugnadslisten
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingBottom: 32 }}
    >
      {/* Tittel */}
      <View style={styles.headerSection}>
        <Text style={styles.title}>Mine dugnader</Text>
        <Text style={styles.subtitle}>
          Oversikt over dugnader du har meldt deg på
        </Text>
      </View>

      {/* Statistikk-ruter */}
      <View style={styles.statsGrid}>
        <StatCard
          label="Totalt"
          value={
            statsLoading || !stats ? '–' : String(stats.totalParticipations)
          }
          emoji="📈"
        />
        <StatCard
          label="Kommende"
          value={
            statsLoading || !stats ? '–' : String(stats.upcomingDugnads)
          }
          emoji="📅"
        />
        <StatCard
          label="Fullførte"
          value={
            statsLoading || !stats ? '–' : String(stats.completedDugnads)
          }
          emoji="✅"
        />
        <StatCard
          label="Favoritter"
          value={statsLoading || !stats ? '–' : String(stats.favorites)}
          emoji="❤️"
        />
      </View>

      {/* Filterknapper */}
      <View style={styles.filterRow}>
        <FilterChip
          label="Kommende"
          active={filter === 'upcoming'}
          onPress={() => setFilter('upcoming')}
        />
        <FilterChip
          label="Pågående"
          active={filter === 'ongoing'}
          onPress={() => setFilter('ongoing')}
        />
        <FilterChip
          label="Fullførte"
          active={filter === 'completed'}
          onPress={() => setFilter('completed')}
        />
        <FilterChip
          label="Favoritter"
          active={filter === 'favorites'}
          onPress={() => setFilter('favorites')}
        />
      </View>

      {/* Liste */}
      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator />
        </View>
      ) : filtered.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyText}>
            Ingen dugnader i denne kategorien ennå.
          </Text>
        </View>
      ) : (
        filtered.map((item) => (
          <View key={item.dugnad.id} style={{ marginBottom: 16 }}>
            <DugnadCard
              dugnad={item.dugnad}
              onPress={() => handleOpenDetails(item.dugnad)}
              isFavorite={item.isFavorite}
              onToggleFavorite={() => handleToggleFavorite(item)}
            />
          </View>
        ))
      )}

      {mutating && (
        <Text style={styles.mutatingHint}>
          Oppdaterer favoritter …
        </Text>
      )}
    </ScrollView>
  );
}

/* -----------------------------------
 * Små presentasjonskomponenter
 * ----------------------------------- */

// Kort med statistikk på toppen
interface StatCardProps {
  label: string;
  value: string;
  emoji: string;
}

const StatCard: React.FC<StatCardProps> = ({ label, value, emoji }) => {
  return (
    <View style={styles.statCard}>
      <Text style={styles.statLabel}>{label}</Text>
      <View style={styles.statBottomRow}>
        <Text style={styles.statValue}>{value}</Text>
        <Text style={styles.statEmoji}>{emoji}</Text>
      </View>
    </View>
  );
};

// Filter-knapp
interface FilterChipProps {
  label: string;
  active: boolean;
  onPress: () => void;
}

const FilterChip: React.FC<FilterChipProps> = ({
  label,
  active,
  onPress,
}) => (
  <TouchableOpacity
    onPress={onPress}
    style={[styles.chip, active && styles.chipActive]}
  >
    <Text style={[styles.chipText, active && styles.chipTextActive]}>
      {label}
    </Text>
  </TouchableOpacity>
);


// Styling
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 16,
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 24,
  },
  headerSection: {
    marginTop: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    color: Colors.textMuted,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -6,
    marginBottom: 16,
  },
  statCard: {
    width: '50%',
    paddingHorizontal: 6,
    marginBottom: 12,
  },
  statLabel: {
    fontSize: 12,
    color: Colors.textMuted,
    marginBottom: 4,
  },
  statBottomRow: {
    backgroundColor: '#fff',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: Colors.border,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: '600',
  },
  statEmoji: {
    fontSize: 20,
    opacity: 0.7,
  },
  filterRow: {
    flexDirection: 'row',
    backgroundColor: '#F3F4F6',
    borderRadius: 999,
    padding: 4,
    marginBottom: 16,
  },
  chip: {
    flex: 1,
    borderRadius: 999,
    paddingVertical: 8,
    alignItems: 'center',
  },
  chipActive: {
    backgroundColor: '#ffffff',
  },
  chipText: {
    fontSize: 13,
    color: Colors.textMuted,
    fontWeight: '500',
  },
  chipTextActive: {
    color: '#000000',
  },
  empty: {
    paddingVertical: 24,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 13,
    color: Colors.textMuted,
  },
  mutatingHint: {
    marginTop: 4,
    fontSize: 11,
    color: Colors.textMuted,
    textAlign: 'center',
  },
});
