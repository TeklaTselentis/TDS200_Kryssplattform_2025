import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useNavigation } from 'expo-router';
import Colors from '../../constants/Colors';
import { useAuth } from '../../providers/authctx';
import HomeHeader from '../../components/HomeHeader';
import AdminDashboard from './admin';

// Hovedkomponenten for profilsiden, viser brukerinfo, logg ut og admin-dashboard (kun for arrangør)
export default function ProfileScreen() {
  const { user, signOut } = useAuth();
  const router = useRouter();
  const navigation = useNavigation<any>();

  useEffect(() => {
    navigation.setOptions({ headerShown: false });
  }, [navigation]);

  if (!user) {
    return (
      <View style={styles.center}>
        <Text>Laster...</Text>
      </View>
    );
  }

  const initials =
    user.name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase() || 'D';

  const roleLabel = user.role === 'organizer' ? 'Arrangør' : 'Frivillig';
  const role = user.role ?? 'volunteer';
  const isOrganizer = role === 'organizer';

  const handleLogout = async () => {
    try {
      await signOut();
      router.replace('/authentication');
    } catch (e) {
      console.error(e);
      Alert.alert('Feil', 'Kunne ikke logge ut.');
    }
  };

  //Bottombar tilgjengelig på opprett profil siden
  const bottomTabs = [
    { key: 'home', 
      label: 'Hjem', 
      icon: 'home-outline' as const, route: '/' },
    {
      key: 'activity',
      label: 'Mine dugnader',
      icon: 'heart-outline' as const,
      route: '/activity',
    },
    { key: 'map', 
      label: 'Kart', 
      icon: 'map-outline' as const, 
      route: '/map' },
  ];

  return (
    <View style={styles.root}>
      <HomeHeader />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.headerSection}>
          <Text style={styles.title}>Profil</Text>
          <Text style={styles.subtitle}>
            Din personlige informasjon og innstillinger
          </Text>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{initials}</Text>
            </View>
          </View>

          <View style={styles.row}>
            <View style={styles.iconCircle}>
              <Ionicons name="person-outline" size={18} color="#4B5563" />
            </View>
            <View style={styles.rowTextWrapper}>
              <Text style={styles.rowLabel}>Navn</Text>
              <Text style={styles.rowValue}>{user.name}</Text>
            </View>
          </View>

          <View style={styles.row}>
            <View style={styles.iconCircle}>
              <Ionicons name="mail-outline" size={18} color="#4B5563" />
            </View>
            <View style={styles.rowTextWrapper}>
              <Text style={styles.rowLabel}>E-post</Text>
              <Text style={styles.rowValue}>{user.email}</Text>
            </View>
          </View>

          <View style={styles.row}>
            <View style={styles.iconCircle}>
              <Ionicons
                name="shield-checkmark-outline"
                size={18}
                color="#4B5563"
              />
            </View>
            <View style={styles.rowTextWrapper}>
              <Text style={styles.rowLabel}>Brukertype</Text>
              <View style={styles.roleBadge}>
                <Text style={styles.roleBadgeText}>{roleLabel}</Text>
              </View>
            </View>
          </View>

          <Pressable
            onPress={handleLogout}
            style={({ pressed }) => [
              styles.logoutRow,
              pressed && styles.logoutRowPressed,
            ]}
          >
            <View style={styles.iconCircleLogout}>
              <Ionicons name="log-out-outline" size={18} color="#EF4444" />
            </View>
            <View style={styles.rowTextWrapper}>
              <Text style={styles.logoutTitle}>Logg ut</Text>
              <Text style={styles.logoutSubtitle}>Avslutt økten din</Text>
            </View>
          </Pressable>
        </View>
        {isOrganizer && <AdminDashboard />}
      </ScrollView>

      <View style={styles.bottomBar}>
        {bottomTabs.map((tab) => (
          <Pressable
            key={tab.key}
            style={styles.bottomTab}
            onPress={() => router.replace(tab.route as any)}
          >
            <Ionicons name={tab.icon} size={22} color="#111827" />
            <Text style={styles.bottomTabLabel}>{tab.label}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

// Styling
const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scroll: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 100,
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  headerSection: {
    marginBottom: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: '600',
  },
  subtitle: {
    marginTop: 4,
    fontSize: 13,
    color: Colors.textMuted,
  },

  card: {
    borderRadius: 18,
    backgroundColor: '#FFFFFF',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: Colors.border,
  },

  cardHeader: {
    backgroundColor: '#EEF3FF',
    alignItems: 'center',
    paddingVertical: 24,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: '700',
  },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  rowTextWrapper: {
    flex: 1,
  },
  iconCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  rowLabel: {
    fontSize: 12,
    color: Colors.textMuted,
    marginBottom: 2,
  },
  rowValue: {
    fontSize: 14,
    fontWeight: '500',
  },

  roleBadge: {
    marginTop: 4,
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: '#F3F4F6',
  },
  roleBadgeText: {
    fontSize: 12,
    fontWeight: '500',
  },

  logoutRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderTopWidth: 1,
    borderTopColor: '#FEE2E2',
    backgroundColor: '#FEF2F2',
  },
  logoutRowPressed: {
    backgroundColor: '#FEE2E2',
  },
  iconCircleLogout: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FEE2E2',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  logoutTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#B91C1C',
  },
  logoutSubtitle: {
    fontSize: 12,
    color: '#B91C1C',
    marginTop: 2,
  },

  bottomBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingTop: 9,
    paddingBottom: Platform.OS === 'ios' ? 20 : 12,
    paddingHorizontal: 24,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    height: Platform.OS === 'ios' ? 72 : 64,
  },
  bottomTab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomTabLabel: {
    marginTop: 2,
    fontSize: 11,
  },
});
