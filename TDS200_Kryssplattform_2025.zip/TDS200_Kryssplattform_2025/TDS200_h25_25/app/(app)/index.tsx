import { Redirect } from 'expo-router';

// Omdirigerer appens rot til (tabs)
export default function AppIndex() {
    return <Redirect href={'(tabs)' as any} />;
}
