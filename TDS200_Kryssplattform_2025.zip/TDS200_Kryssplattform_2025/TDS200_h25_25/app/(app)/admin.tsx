import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import Colors from '../../constants/Colors';
import type { Dugnad, User } from '../../types';
import {
  getDugnads,
  getAllUsers,
  getAllRegistrations,
  type Registration,
} from '../../api/firebase';
import { getComputedStatus } from '../../utils/dugnadUtils';

// Typer for tabbene i admin-skjermen
type AdminTab = 'dugnads' | 'users' | 'popular';

// Hovedkomponenten for admin-skjermen
export default function AdminScreen() {
  const [dugnads, setDugnads] = useState<Dugnad[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [activeTab, setActiveTab] = useState<AdminTab>('dugnads');
  const [loading, setLoading] = useState(true);

  // Hent data ved komponentmontering
  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [d, u, r] = await Promise.all([
          getDugnads(),
          getAllUsers(),
          getAllRegistrations(),
        ]);
        setDugnads(d);
        setUsers(u);
        setRegistrations(r);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);


  // Beregn statistikkverdier
  const totalDugnads = dugnads.length;
  const totalRegistrations = registrations.length;
  const avgPerDugnad =
    totalDugnads === 0 ? 0 : totalRegistrations / totalDugnads;

  // Statusfordeling
  const kommendeCount = dugnads.filter(
    (d) => getComputedStatus(d) === 'upcoming'
  ).length;
  const fullforteCount = dugnads.filter(
    (d) => getComputedStatus(d) === 'completed'
  ).length;
  const paagaaendeCount = dugnads.filter(
    (d) => getComputedStatus(d) === 'ongoing'
  ).length;

  // Brukerroller
  const volunteersCount = users.filter((u) => u.role === 'volunteer').length;
  const organizersCount = users.filter((u) => u.role === 'organizer').length;
  const activeUsers = users.length;

  // ugnader m/registreringstall og kapasitet
  const dugnadsWithCounts = useMemo(() => {
    return dugnads.map((d) => {
      const count = registrations.filter((r) => r.dugnadId === d.id).length;
      const capacity = d.volunteersNeeded ?? 0;
      return {
        ...d,
        registrationsCount: count,
        capacity,
      };
    });
  }, [dugnads, registrations]);

  // Sortert liste etter “fyllingsgrad” (registrations/capacity)
  const popular = useMemo(() => {
    const list = [...dugnadsWithCounts];
    list.sort((a, b) => {
      const pa =
        a.capacity === 0 ? 0 : a.registrationsCount / a.capacity;
      const pb =
        b.capacity === 0 ? 0 : b.registrationsCount / b.capacity;
      return pb - pa;
    });
    return list;
  }, [dugnadsWithCounts]);

  // Render loading state
  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator />
        <Text style={styles.loaderText}>Laster admin-data…</Text>
      </View>
    );
  }

  //Hovedinnhold
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingBottom: 32 }}
    >
      {/* Header-tekst under global DugnadHub-header */}
      <View style={styles.headerSection}>
        <Text style={styles.title}>Admin Dashboard</Text>
        <Text style={styles.subtitle}>
          Oversikt over plattformens statistikk og aktivitet
        </Text>
      </View>

      {/* Statistikk 2x2 kort */}
      <View style={styles.statsGrid}>
        <StatCard
          label="Totalt dugnader"
          value={String(totalDugnads)}
        />
        <StatCard
          label="Aktive brukere"
          value={String(activeUsers)}
        />
        <StatCard
          label="Påmeldinger"
          value={String(totalRegistrations)}
        />
        <StatCard
          label="Snitt per dugnad"
          value={avgPerDugnad.toFixed(1)}
        />
      </View>

      {/* Dugnadsstatus */}
      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Dugnad status</Text>

        <StatusRow label="Kommende" value={kommendeCount} />
        <StatusRow label="Fullførte" value={fullforteCount} />
        <StatusRow label="Pågående" value={paagaaendeCount} />
      </View>

      {/* Brukerroller */}
      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Brukerroller</Text>

        <StatusRow label="Frivillige" value={volunteersCount} />
        <StatusRow label="Arrangører" value={organizersCount} />
      </View>

      {/* Tabs: Dugnader / Brukere / Populære */}
      <View style={styles.tabsContainer}>
        <AdminTabChip
          label="Dugnader"
          active={activeTab === 'dugnads'}
          onPress={() => setActiveTab('dugnads')}
        />
        <AdminTabChip
          label="Brukere"
          active={activeTab === 'users'}
          onPress={() => setActiveTab('users')}
        />
        <AdminTabChip
          label="Populære"
          active={activeTab === 'popular'}
          onPress={() => setActiveTab('popular')}
        />
      </View>

      {/* Innhold per tab */}
      {activeTab === 'dugnads' && (
        <View>
          {dugnadsWithCounts.map((d) => {
            const status = getComputedStatus(d);
            return (
              <AdminDugnadCard
                key={d.id}
                title={d.title}
                category={d.category}
                date={formatDate(d.date)}
                participants={d.registrationsCount}
                capacity={d.capacity}
                organizer={d.organizerName ?? 'Arrangør'}
                status={statusLabel(status)}
              />
            );
          })}
        </View>
      )}

      {activeTab === 'users' && (
        <View>
          {users.map((u) => (
            <AdminUserCard
              key={u.id}
              name={u.name}
              email={u.email}
              registrations={registrations.filter(
                (r) => r.userId === u.id
              ).length}
            />
          ))}
        </View>
      )}

      {activeTab === 'popular' && (
        <View>
          {popular.map((d, index) => {
            const percent =
              d.capacity === 0
                ? 0
                : Math.round(
                  (d.registrationsCount / d.capacity) * 100
                );
            return (
              <PopularDugnadCard
                key={d.id}
                rank={index + 1}
                title={d.title}
                category={d.category}
                participants={d.registrationsCount}
                capacity={d.capacity}
                percent={percent}
              />
            );
          })}
        </View>
      )}
    </ScrollView>
  );
}


// Returnerer norsk label for status
function statusLabel(status: string) {
  if (status === 'upcoming') return 'Kommende';
  if (status === 'ongoing') return 'Pågående';
  if (status === 'completed') return 'Fullført';
  return 'Avlyst';
}

// Formaterer dato til norsk format DD.MM.YYYY
function formatDate(value: any) {
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleDateString('nb-NO', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
}

// Presentasjonskort for topp-statistikk
const StatCard: React.FC<{ label: string; value: string }> = ({
  label,
  value,
}) => (
  <View style={styles.statCard}>
    <Text style={styles.statLabel}>{label}</Text>
    <View style={styles.statValueBox}>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  </View>
);

// Rad for statusvisning
const StatusRow: React.FC<{ label: string; value: number }> = ({
  label,
  value,
}) => (
  <View style={styles.statusRow}>
    <Text style={styles.statusLabel}>{label}</Text>
    <View style={styles.statusPill}>
      <Text style={styles.statusPillText}>{value}</Text>
    </View>
  </View>
);

// Tab-knapp for å bytte innhold
const AdminTabChip: React.FC<{
  label: string;
  active: boolean;
  onPress: () => void;
}> = ({ label, active, onPress }) => (
  <TouchableOpacity
    onPress={onPress}
    style={[styles.tabChip, active && styles.tabChipActive]}
  >
    <Text
      style={[styles.tabChipText, active && styles.tabChipTextActive]}
    >
      {label}
    </Text>
  </TouchableOpacity>
);

// Kort for en enkelt dugnad i admin-listen
const AdminDugnadCard: React.FC<{
  title: string;
  category: string;
  date: string;
  participants: number;
  capacity: number;
  organizer: string;
  status: string;
}> = ({ title, category, date, participants, capacity, organizer, status }) => (
  <View style={styles.dugnadCard}>
    <View style={styles.dugnadCardHeader}>
      <View style={{ flex: 1 }}>
        <Text style={styles.dugnadTitle}>{title}</Text>
        <Text style={styles.dugnadCategory}>{category}</Text>
      </View>
      <View style={styles.dugnadStatusPill}>
        <Text style={styles.dugnadStatusText}>{status}</Text>
      </View>
    </View>

    <View style={styles.dugnadRow}>
      <Text style={styles.dugnadMeta}>
        📅 {date}   👥 {participants}/{capacity}
      </Text>
    </View>
    <Text style={styles.dugnadMeta}>Arrangør: {organizer}</Text>
  </View>
);

// Kort for en enkelt bruker i admin-listen
const AdminUserCard: React.FC<{
  name: string;
  email: string;
  registrations: number;
}> = ({ name, email, registrations }) => (
  <View style={styles.userCard}>
    <View style={styles.userAvatar}>
      <Text style={styles.userAvatarText}>
        {name.charAt(0).toUpperCase()}
      </Text>
    </View>
    <View style={{ flex: 1 }}>
      <Text style={styles.userName}>{name}</Text>
      <Text style={styles.userEmail}>{email}</Text>
    </View>
    <View style={styles.userRight}>
      <View style={styles.userStatusPill}>
        <Text style={styles.userStatusText}>Aktiv bruker</Text>
      </View>
      <Text style={styles.userRegistrations}>
        {registrations} påmeldinger
      </Text>
    </View>
  </View>
);

// Kort for populære dugnader i admin-listen
const PopularDugnadCard: React.FC<{
  rank: number;
  title: string;
  category: string;
  participants: number;
  capacity: number;
  percent: number;
}> = ({ rank, title, category, participants, capacity, percent }) => (
  <View style={styles.popularCard}>
    <View style={styles.popularLeftCircle}>
      <Text style={styles.popularLeftCircleText}>#{rank}</Text>
    </View>
    <View style={{ flex: 1 }}>
      <Text style={styles.dugnadTitle}>{title}</Text>
      <Text style={styles.dugnadCategory}>{category}</Text>

      <View style={styles.progressBarWrapper}>
        <View style={styles.progressBarBackground}>
          <View
            style={[
              styles.progressBarFill,
              { width: `${percent}%` },
            ]}
          />
        </View>
        <Text style={styles.progressPercent}>{percent}%</Text>
      </View>

      <Text style={styles.dugnadMeta}>
        {participants} av {capacity} påmeldt
      </Text>
    </View>
  </View>
);

// Styling
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 16,
  },
  loader: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loaderText: {
    marginTop: 8,
    fontSize: 13,
    color: Colors.textMuted,
  },
  headerSection: {
    marginTop: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    color: Colors.textMuted,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -6,
    marginBottom: 16,
  },
  statCard: {
    width: '50%',
    paddingHorizontal: 6,
    marginBottom: 12,
  },
  statLabel: {
    fontSize: 12,
    color: Colors.textMuted,
    marginBottom: 4,
  },
  statValueBox: {
    backgroundColor: '#fff',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  statValue: {
    fontSize: 20,
    fontWeight: '600',
  },
  sectionCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 16,
    paddingVertical: 16,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
  },
  statusLabel: {
    fontSize: 14,
  },
  statusPill: {
    minWidth: 32,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
  },
  statusPillText: {
    fontSize: 13,
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: '#EEF0F4',
    borderRadius: 999,
    padding: 4,
    marginBottom: 12,
    marginTop: 8,
  },
  tabChip: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
    borderRadius: 999,
  },
  tabChipActive: {
    backgroundColor: '#ffffff',
  },
  tabChipText: {
    fontSize: 13,
    color: Colors.textMuted,
    fontWeight: '500',
  },
  tabChipTextActive: {
    color: '#000',
    fontWeight: '600',
  },
  dugnadCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 12,
  },
  dugnadCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  dugnadTitle: {
    fontSize: 15,
    fontWeight: '600',
  },
  dugnadCategory: {
    fontSize: 12,
    color: Colors.textMuted,
  },
  dugnadStatusPill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: '#111827',
  },
  dugnadStatusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#fff',
  },
  dugnadRow: {
    marginTop: 4,
    marginBottom: 2,
  },
  dugnadMeta: {
    fontSize: 12,
    color: Colors.textMuted,
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 10,
  },
  userAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  userAvatarText: {
    fontSize: 16,
    fontWeight: '600',
  },
  userName: {
    fontSize: 14,
    fontWeight: '600',
  },
  userEmail: {
    fontSize: 12,
    color: Colors.textMuted,
  },
  userRight: {
    alignItems: 'flex-end',
    marginLeft: 12,
  },
  userStatusPill: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 4,
    backgroundColor: '#F3F4FF',
  },
  userStatusText: {
    fontSize: 11,
    color: '#111827',
  },
  userRegistrations: {
    marginTop: 4,
    fontSize: 12,
    color: Colors.textMuted,
  },
  popularCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 12,
  },
  popularLeftCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E5F0FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  popularLeftCircleText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1D4ED8',
  },
  progressBarWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 2,
  },
  progressBarBackground: {
    flex: 1,
    height: 6,
    borderRadius: 999,
    backgroundColor: '#E5E7EB',
    marginRight: 8,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 999,
    backgroundColor: Colors.primary,
  },
  progressPercent: {
    fontSize: 11,
    color: Colors.textMuted,
  },
});
