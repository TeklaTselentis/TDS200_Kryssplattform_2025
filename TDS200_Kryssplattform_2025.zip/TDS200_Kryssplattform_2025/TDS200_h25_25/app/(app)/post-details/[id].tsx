import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Alert,
  Image,
  TouchableOpacity,
  TextInput,
  Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Colors from '../../../constants/Colors';
import { useAuth } from '../../../providers/authctx';
import type { Dugnad } from '../../../types';
import {
  getDugnadById,
  getFavoritesForUser,
  getRegistrationsForUser,
  getRegistrationsForDugnad,
  registerForDugnad,
  unregisterFromDugnad,
  toggleFavorite,
  addDugnadComment,
  getDugnadComments,
  deleteDugnadComment,
  getDugnadCommentLikesForUser,
  toggleDugnadCommentLike,
  deleteDugnad,
} from '../../../api/firebase';
import {
  getComputedStatus,
  formatDugnadDateTime,
} from '../../../utils/dugnadUtils';
import { Button } from '../../../components/ui/Button';
import HomeHeader from '../../../components/HomeHeader';
import { CreateDugnadForm } from '../../../components/CreateDugnadForm';


// View-modell for kommentar
type CommentVm = {
  id: string;
  userId: string;
  author: string;
  text: string;
  date: string;
  likeCount: number;
  hasLiked: boolean;
};

// Hovedkomponenten for dugnadsdetaljer
export default function DugnadDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { user } = useAuth();
  const [dugnad, setDugnad] = useState<Dugnad | null>(null);
  const [loading, setLoading] = useState(true);
  const [mutating, setMutating] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'info' | 'participants' | 'comments'>('info');
  const [participants, setParticipants] = useState<{ id: string; name: string; joinedAt: string }[]>([]);
  const [comments, setComments] = useState<CommentVm[]>([]);
  const [newComment, setNewComment] = useState('');
  const [commentMutating, setCommentMutating] = useState(false);

  // Tilbake-knapp handler
  const handleBack = () => {
    if (router.canGoBack()) {
      router.back();
    } else {
      router.replace('../(tabs)/home');
    }
  };

  // Laster dugnad-data
  const loadData = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const d = await getDugnadById(String(id));
      if (!d) {
        setError('Fant ikke dugnaden.');
        setDugnad(null);
        return;
      }
      setDugnad(d);

      const regsForThis = await getRegistrationsForDugnad(d.id);
      setParticipants(
        regsForThis.map((r: any) => ({
          id: r.id,
          name: r.userName,
          joinedAt: r.createdAt
            ? new Date(r.createdAt).toISOString()
            : '',
        }))
      );

      // Hent kommentarer
      const rawComments = await getDugnadComments(d.id);

      // Hent likes for innlogget bruker
      let likedIds: string[] = [];
      if (user) {
        likedIds = await getDugnadCommentLikesForUser({
          dugnadId: d.id,
          userId: user.id,
        });
      }

      // Map til view-modell
      setComments(
        rawComments.map((c) => ({
          id: c.id,
          userId: c.userId,
          author: c.userName,
          text: c.text,
          date: c.createdAt
            ? new Date(c.createdAt).toLocaleString('no-NO')
            : '',
          likeCount: c.likeCount ?? 0,
          hasLiked: likedIds.includes(c.id),
        }))
      );

      // Registrering/favoritt for innlogget bruker
      if (user) {
        const [regs, favs] = await Promise.all([
          getRegistrationsForUser(user.id),
          getFavoritesForUser(user.id),
        ]);

        const reg = regs.find(
          (r) => r.dugnadId === d.id && r.status === 'registered'
        );
        const fav = favs.find((f) => f.dugnadId === d.id);

        setIsRegistered(!!reg);
        setIsFavorite(!!fav);
      } else {
        setIsRegistered(false);
        setIsFavorite(false);
      }
    } catch (e) {
      console.error('Feil ved henting av dugnad', e);
      setError('Noe gikk galt ved henting av dugnaden.');
    } finally {
      setLoading(false);
    }
  }, [id, user]);

  // Laster data ved mount og ved id-endring
  useEffect(() => {
    loadData();
  }, [loadData]);

  // Håndterer favoritt-trykk
  const handleToggleFavorite = async () => {
    if (!user || !dugnad) return;
    setMutating(true);
    try {
      await toggleFavorite({ dugnadId: dugnad.id, userId: user.id });
      setIsFavorite((prev) => !prev);
    } catch (e) {
      console.error('Feil ved favorisering', e);
      Alert.alert('Feil', 'Kunne ikke oppdatere favoritt.');
    } finally {
      setMutating(false);
    }
  };

  // Håndterer påmelding/avmelding
  const handleRegister = async () => {
    if (!user || !dugnad) return;

    // Avmelding
    if (isRegistered) {
      setMutating(true);
      try {
        await unregisterFromDugnad({ dugnadId: dugnad.id, userId: user.id });
        setIsRegistered(false);
        setDugnad((prev) =>
          prev
            ? {
              ...prev,
              volunteersRegistered:
                prev.volunteersRegistered > 0
                  ? prev.volunteersRegistered - 1
                  : 0,
            }
            : prev
        );
        setParticipants((prev) =>
          prev.filter((p) => p.id !== `${user.id}_${dugnad.id}`)
        );
      } catch (e) {
        console.error('Feil ved avmelding', e);
        Alert.alert('Feil', 'Kunne ikke melde deg av dugnaden.');
      } finally {
        setMutating(false);
      }
      return;
    }

    // Sjekk kapasitet før påmelding
    if (dugnad.volunteersRegistered >= dugnad.volunteersNeeded) {
      Alert.alert('Fullt', 'Denne dugnaden er allerede full.');
      return;
    }

    // Påmelding
    setMutating(true);
    try {
      await registerForDugnad({
        dugnadId: dugnad.id,
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
      });
      setIsRegistered(true);
      setDugnad((prev) =>
        prev
          ? {
            ...prev,
            volunteersRegistered: prev.volunteersRegistered + 1,
          }
          : prev
      );
      setParticipants((prev) => [
        ...prev,
        {
          id: `${user.id}_${dugnad.id}`,
          name: user.name,
          joinedAt: new Date().toISOString(),
        },
      ]);
    } catch (e) {
      console.error('Feil ved påmelding', e);
      Alert.alert('Feil', 'Kunne ikke melde deg på dugnaden.');
    } finally {
      setMutating(false);
    }
  };


  // Håndterer ny kommentar
  const handleAddComment = async () => {
    if (!user || !dugnad) return;
    const trimmed = newComment.trim();
    if (!trimmed) return;

    setCommentMutating(true);
    try {
      const created = await addDugnadComment({
        dugnadId: dugnad.id,
        userId: user.id,
        userName: user.name,
        text: trimmed,
      });

      setComments((prev) => [
        {
          id: created.id,
          userId: created.userId,
          author: created.userName,
          text: created.text,
          date: created.createdAt
            ? new Date(created.createdAt).toLocaleString('no-NO')
            : '',
          likeCount: created.likeCount ?? 0,
          hasLiked: false,
        },
        ...prev,
      ]);
      setNewComment('');
    } catch (e) {
      console.error('Feil ved lagring av kommentar', e);
      Alert.alert('Feil', 'Kunne ikke lagre kommentaren.');
    } finally {
      setCommentMutating(false);
    }
  };

  // Håndterer sletting av kommentar
  const handleDeleteCommentPress = (commentId: string, ownerId: string) => {
    if (!user || user.id !== ownerId) return;

    const doDelete = async () => {
      try {
        await deleteDugnadComment({ commentId, userId: user.id });
        setComments((prev) => prev.filter((c) => c.id !== commentId));
      } catch (e) {
        console.error('Feil ved sletting av kommentar', e);
        Alert.alert('Feil', 'Kunne ikke slette kommentaren.');
      }
    };

    // Bekreftelsesdialog på mobil, direkte på web
    if (Platform.OS === 'web') {
      void doDelete();
    } else {
      Alert.alert(
        'Slett kommentar',
        'Er du sikker på at du vil slette denne kommentaren?',
        [
          { text: 'Avbryt', style: 'cancel' },
          {
            text: 'Slett',
            style: 'destructive',
            onPress: () => {
              void doDelete();
            },
          },
        ]
      );
    }
  };

  // Håndterer like/unlike av kommentar
  const handleToggleCommentLike = async (commentId: string) => {
    if (!user || !dugnad) return;
    setComments((prev) =>
      prev.map((c) =>
        c.id === commentId
          ? {
            ...c,
            hasLiked: !c.hasLiked,
            likeCount: c.likeCount + (c.hasLiked ? -1 : 1),
          }
          : c
      )
    );

    try {
      await toggleDugnadCommentLike({
        commentId,
        dugnadId: dugnad.id,
        userId: user.id,
      });
    } catch (e) {
      console.error('Feil ved like/unlike', e);
      setComments((prev) =>
        prev.map((c) =>
          c.id === commentId
            ? {
              ...c,
              hasLiked: !c.hasLiked,
              likeCount: c.likeCount + (c.hasLiked ? -1 : 1),
            }
            : c
        )
      );
    }
  };


  // Laster innhold basert på tilstand
  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
        <Text style={styles.centerText}>Laster dugnad...</Text>
      </View>
    );
  }

  // Feilhåndtering
  if (error || !dugnad) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>{error ?? 'Fant ikke dugnaden.'}</Text>
        <Button
          title="Tilbake"
          variant="outline"
          onPress={handleBack}
          style={{ marginTop: 12 }}
        />
      </View>
    );
  }


  // Beregninger for visning
  const status = getComputedStatus(dugnad);
  const isOrganizer = user?.id === dugnad.organizerId;
  const isFull =
    dugnad.volunteersRegistered >= dugnad.volunteersNeeded &&
    !isRegistered &&
    status !== 'completed';
  const remaining =
    dugnad.volunteersNeeded - dugnad.volunteersRegistered > 0
      ? dugnad.volunteersNeeded - dugnad.volunteersRegistered
      : 0;

  // Label for status-pill
  const statusLabel =
    status === 'upcoming'
      ? 'Kommende'
      : status === 'ongoing'
        ? 'Pågår'
        : status === 'completed'
          ? 'Fullført'
          : 'Avlyst';


  // Håndterer trykk på rediger-knapp
  const handleEditPress = () => {
    if (!dugnad || !isOrganizer) return;
    setIsEditing(true);
    setActiveTab('info');
  };

  // Håndterer avbryt redigering
  const handleEditCancel = () => {
    setIsEditing(false);
  };

  // Håndterer lagring etter redigering
  const handleEditSaved = async () => {
    await loadData();
    setIsEditing(false);
  };

  // Håndterer sletting av dugnad
  const handleDeletePress = () => {
    if (!dugnad || !isOrganizer) return;

    const doDelete = async () => {
      try {
        await deleteDugnad({ dugnadId: dugnad.id });
        handleBack();
      } catch (e) {
        console.error('Feil ved sletting av dugnad', e);
        Alert.alert('Feil', 'Kunne ikke slette dugnaden.');
      }
    };


    if (Platform.OS === 'web') {
      void doDelete();
    } else {
      Alert.alert(
        'Slett dugnad',
        'Er du sikker på at du vil slette denne dugnaden?',
        [
          { text: 'Avbryt', style: 'cancel' },
          {
            text: 'Slett',
            style: 'destructive',
            onPress: () => {
              void doDelete();
            },
          },
        ]
      );
    }
  };


  // Redigeringsmodus: viser skjema for å oppdatere dugnaden
  if (isEditing) {
    return (
      <View style={styles.root}>
        <HomeHeader />
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={{ paddingBottom: 120 }}
        >
          <View style={styles.topRow}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={handleEditCancel}
            >
              <Ionicons name="chevron-back" size={24} color="#111827" />
            </TouchableOpacity>
          </View>

          <View style={styles.section}>
            <Text style={styles.title}>Rediger dugnad</Text>
          </View>


          <CreateDugnadForm
            initialDugnad={dugnad}
            onSaved={handleEditSaved}
            onCancel={handleEditCancel}
          />
        </ScrollView>
      </View>
    );
  }

  // Hovedvisning av dugnadsdetaljer
  return (
    <View style={styles.root}>
      <HomeHeader />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: 120 }}
      >
        <View style={styles.topRow}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={handleBack}
          >
            <Ionicons name="chevron-back" size={24} color="#111827" />
          </TouchableOpacity>

          <View style={styles.topActions}>
            {isOrganizer && (
              <>
                <TouchableOpacity
                  style={styles.iconButton}
                  onPress={handleEditPress}
                >
                  <Ionicons name="create-outline" size={20} color="#111827" />
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.iconButton}
                  onPress={handleDeletePress}
                >
                  <Ionicons name="trash-outline" size={20} color="#b91c1c" />
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>

        <View style={styles.imageWrapper}>
          {dugnad.images?.[0] ? (
            <Image source={{ uri: dugnad.images[0] }} style={styles.image} />
          ) : (
            <View style={styles.imagePlaceholder}>
              <Ionicons name="image-outline" size={30} color="#ffffff" />
            </View>
          )}

          <View style={styles.imageTopRow}>
            <View style={styles.categoryPill}>
              <Text style={styles.categoryPillText}>{dugnad.category}</Text>
            </View>
            <View style={styles.statusPill}>
              <Text style={styles.statusPillText}>{statusLabel}</Text>
            </View>

            <TouchableOpacity
              style={styles.favoriteButton}
              onPress={handleToggleFavorite}
              activeOpacity={mutating ? 1 : 0.7}
              disabled={mutating}
            >
              <Ionicons
                name={isFavorite ? 'heart' : 'heart-outline'}
                size={20}
                color={isFavorite ? '#e11d48' : '#111827'}
              />
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.section}>
          <Text style={styles.title}>{dugnad.title}</Text>
          <Text style={styles.description}>{dugnad.description}</Text>
        </View>
        <View style={styles.tabsRow}>
          <TouchableOpacity
            style={[
              styles.tabItem,
              activeTab === 'info' && styles.tabItemActive,
            ]}
            onPress={() => setActiveTab('info')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === 'info' && styles.tabTextActive,
              ]}
            >
              Info
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.tabItem,
              activeTab === 'participants' && styles.tabItemActive,
            ]}
            onPress={() => setActiveTab('participants')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === 'participants' && styles.tabTextActive,
              ]}
            >
              Deltakere ({participants.length})
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.tabItem,
              activeTab === 'comments' && styles.tabItemActive,
            ]}
            onPress={() => setActiveTab('comments')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === 'comments' && styles.tabTextActive,
              ]}
            >
              Kommentarer ({comments.length})
            </Text>
          </TouchableOpacity>
        </View>

        {/* TAB-INNHOLD */}
        {activeTab === 'info' && (
          <View style={styles.section}>
            {/* Dato */}
            <View style={styles.infoRow}>
              <Ionicons
                name="calendar-outline"
                size={18}
                color={Colors.primary}
                style={styles.infoIcon}
              />
              <View>
                <Text style={styles.infoLabel}>Dato</Text>
                <Text style={styles.infoValue}>
                  {String(formatDugnadDateTime(dugnad))}
                </Text>
              </View>
            </View>

            {/* Tid */}
            <View style={styles.infoRow}>
              <Ionicons
                name="time-outline"
                size={18}
                color={Colors.primary}
                style={styles.infoIcon}
              />
              <View>
                <Text style={styles.infoLabel}>Tid</Text>
                <Text style={styles.infoValue}>
                  {dugnad.startTime} – {dugnad.endTime}
                </Text>
              </View>
            </View>

            {/* Sted */}
            <View style={styles.infoRow}>
              <Ionicons
                name="location-outline"
                size={18}
                color={Colors.primary}
                style={styles.infoIcon}
              />
              <View>
                <Text style={styles.infoLabel}>Sted</Text>
                <Text style={styles.infoValue}>{dugnad.location}</Text>
                <Text style={styles.infoSub}>{dugnad.address}</Text>
              </View>
            </View>

            {/* Frivillige */}
            <View style={styles.infoRow}>
              <Ionicons
                name="people-outline"
                size={18}
                color={Colors.primary}
                style={styles.infoIcon}
              />
              <View>
                <Text style={styles.infoLabel}>Frivillige</Text>
                <Text style={styles.infoValue}>
                  {dugnad.volunteersRegistered} av {dugnad.volunteersNeeded}{' '}
                  påmeldt
                </Text>
                <Text style={styles.infoRemaining}>
                  {remaining} ledig(e)
                </Text>
              </View>
            </View>

            {/* Kontakt */}
            <View style={styles.infoRow}>
              <Ionicons
                name="mail-outline"
                size={18}
                color={Colors.primary}
                style={styles.infoIcon}
              />
              <View>
                <Text style={styles.infoLabel}>Kontakt</Text>
                <Text style={styles.infoValue}>
                  {dugnad.organizerName ?? 'Arrangør'}
                </Text>
                <Text style={styles.infoSub}>
                  {dugnad.organizerEmail ?? ''}
                </Text>
              </View>
            </View>

            {/* Oppgaver */}
            {dugnad.tasks?.length ? (
              <>
                <View style={styles.divider} />
                <Text style={styles.sectionTitle}>Oppgaver</Text>
                {dugnad.tasks.map((task, idx) => (
                  <View key={idx} style={styles.taskRow}>
                    <Ionicons
                      name="checkmark-circle-outline"
                      size={18}
                      color={Colors.primary}
                      style={{ marginRight: 8 }}
                    />
                    <Text style={styles.infoValue}>{task}</Text>
                  </View>
                ))}
              </>
            ) : null}
          </View>
        )}

        {activeTab === 'participants' && (
          <View style={styles.section}>
            {participants.length === 0 ? (
              <Text style={styles.infoSub}>
                Ingen deltakere er påmeldt ennå.
              </Text>
            ) : (
              participants.map((p) => {
                const joinedLabel = p.joinedAt
                  ? new Date(p.joinedAt).toLocaleDateString('no-NO')
                  : '';

                return (
                  <View key={p.id} style={styles.participantCard}>
                    <View style={styles.participantAvatar}>
                      <Text style={styles.participantAvatarText}>
                        {p.name.charAt(0).toUpperCase()}
                      </Text>
                    </View>
                    <View>
                      <Text style={styles.infoValue}>{p.name}</Text>
                      <Text style={styles.infoSub}>
                        {joinedLabel
                          ? `Påmeldt ${joinedLabel}`
                          : 'Påmeldt'}
                      </Text>
                    </View>
                  </View>
                );
              })
            )}
          </View>
        )}

        {activeTab === 'comments' && (
          <View style={styles.section}>
            {/* Input + knapp */}
            <View style={styles.commentInputWrapper}>
              <TextInput
                style={styles.commentInput}
                placeholder="Skriv en kommentar..."
                placeholderTextColor={Colors.textMuted}
                value={newComment}
                onChangeText={setNewComment}
                multiline
              />
            </View>
            <Button
              title="Legg til kommentar"
              onPress={handleAddComment}
              disabled={
                commentMutating || !newComment.trim() || !user
              }
              style={{ marginTop: 8, marginBottom: 16 }}
            />

            {comments.length === 0 ? (
              <Text style={styles.infoSub}>
                Ingen kommentarer ennå.
              </Text>
            ) : (
              comments.map((c) => (
                <View key={c.id} style={styles.commentCard}>
                  <View style={styles.participantAvatar}>
                    <Text style={styles.participantAvatarText}>
                      {c.author.charAt(0).toUpperCase()}
                    </Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <View style={styles.commentHeaderRow}>
                      <Text style={styles.infoValue}>{c.author}</Text>
                      {user?.id === c.userId && (
                        <TouchableOpacity
                          onPress={() =>
                            handleDeleteCommentPress(c.id, c.userId)
                          }
                        >
                          <Ionicons
                            name="trash-outline"
                            size={16}
                            color="#9CA3AF"
                          />
                        </TouchableOpacity>
                      )}
                    </View>
                    <Text style={[styles.infoValue, { marginTop: 4 }]}>
                      {c.text}
                    </Text>
                    <View style={styles.commentFooterRow}>
                      <Text style={styles.infoSub}>{c.date}</Text>
                      <TouchableOpacity
                        style={styles.likeButton}
                        onPress={() => handleToggleCommentLike(c.id)}
                        disabled={!user}
                      >
                        <Ionicons
                          name={
                            c.hasLiked
                              ? 'thumbs-up'
                              : 'thumbs-up-outline'
                          }
                          size={14}
                          color={
                            c.hasLiked ? Colors.primary : '#6B7280'
                          }
                          style={{ marginRight: 4 }}
                        />
                        {c.likeCount > 0 && (
                          <Text style={styles.likeCountText}>
                            {c.likeCount}
                          </Text>
                        )}
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              ))
            )}
          </View>
        )}
      </ScrollView>

      {/* BUNN-KNAPP */}
      <View style={styles.bottomBar}>
        <Button
          title={
            isRegistered
              ? 'Meld deg av'
              : isFull
                ? 'Fullt'
                : 'Meld deg på'
          }
          onPress={handleRegister}
          disabled={mutating || isFull || status === 'completed'}
        />
      </View>
    </View>
  );
}


// Styling
const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scroll: {
    flex: 1,
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  centerText: {
    marginTop: 8,
    fontSize: 13,
    color: Colors.textMuted,
  },
  errorText: {
    fontSize: 14,
    color: 'red',
    textAlign: 'center',
  },

  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingTop: 8,
    paddingBottom: 4,
  },
  backButton: {
    padding: 4,
  },
  topActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    padding: 6,
    marginLeft: 4,
  },

  imageWrapper: {
    height: 220,
    backgroundColor: '#E5E7EB',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  imagePlaceholder: {
    flex: 1,
    backgroundColor: '#9CA3AF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  imageTopRow: {
    position: 'absolute',
    top: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryPill: {
    borderRadius: 999,
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginRight: 8,
  },
  categoryPillText: {
    fontSize: 11,
    fontWeight: '500',
  },
  statusPill: {
    borderRadius: 999,
    backgroundColor: '#000000',
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginRight: 8,
  },
  statusPillText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  favoriteButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },

  section: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
  },
  description: {
    fontSize: 13,
    color: Colors.text,
  },

  tabsRow: {
    flexDirection: 'row',
    marginTop: 20,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    marginHorizontal: 16,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
  },
  tabItemActive: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    color: Colors.textMuted,
  },
  tabTextActive: {
    color: '#000',
    fontWeight: '600',
  },

  infoRow: {
    flexDirection: 'row',
    marginTop: 12,
  },
  infoIcon: {
    marginRight: 8,
    marginTop: 2,
  },
  infoLabel: {
    fontSize: 12,
    color: Colors.textMuted,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  infoSub: {
    fontSize: 12,
    color: Colors.textMuted,
  },
  infoRemaining: {
    fontSize: 12,
    color: '#059669',
    fontWeight: '500',
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: 16,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 8,
  },
  taskRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },

  participantCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 8,
  },
  participantAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#E5E7EB',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  participantAvatarText: {
    fontSize: 14,
    fontWeight: '600',
  },

  commentCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 8,
  },
  commentHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  commentFooterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 6,
  },
  commentInputWrapper: {
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  commentInput: {
    minHeight: 60,
    fontSize: 13,
    color: Colors.text,
  },
  likeButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  likeCountText: {
    fontSize: 12,
    color: Colors.primary,
  },

  bottomBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingBottom: 16,
    paddingTop: 8,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
});
