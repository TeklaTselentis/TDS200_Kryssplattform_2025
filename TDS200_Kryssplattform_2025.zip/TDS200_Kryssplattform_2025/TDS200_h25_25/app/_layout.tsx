import React from "react";
import { Stack } from "expo-router";
import { AuthProvider } from "../providers/authctx";

// Rotlayout: wrapper hele appen i AuthProvider og definerer hoved-Stack
export default function RootLayout() {
    return (
        <AuthProvider>
            <Stack>
                <Stack.Screen name="authentication" options={{ headerShown: false }} />
                <Stack.Screen name="(app)" options={{ headerShown: false }} />
            </Stack>
        </AuthProvider>
    );
}
