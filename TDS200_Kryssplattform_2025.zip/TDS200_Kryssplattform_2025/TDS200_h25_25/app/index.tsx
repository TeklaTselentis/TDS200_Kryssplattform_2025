import { Redirect } from 'expo-router';

// Omdirigerer appens rot til autentiseringsskjermen
export default function Index() {
    return <Redirect href="/authentication" />;
}
